import type { ID } from '@/lib/types';
import type { PlanEditorField } from '@/containers/common/nav';

export type PlanEditorContainerProps = { id: ID; field?: PlanEditorField };

/** Заглушка потока Б: C-EditPlan / -Period / -Year: окно плана; field — что раскрыть при открытии (INTEGRATION.md 1.2) */
export function PlanEditorContainer(_props: PlanEditorContainerProps) {
  return null;
}
