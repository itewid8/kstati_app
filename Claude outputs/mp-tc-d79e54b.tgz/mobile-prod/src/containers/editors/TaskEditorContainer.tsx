import type { ID } from '@/lib/types';

export type TaskEditorContainerProps = { id: ID | null; occ?: string; date?: string; time?: string; parentId?: ID };

/** Заглушка потока Б: C-EditDate / -Repeat / -Remind / -Who: окно дела. id null — новое дело (date, time, parentId); s.editorSeed — черновик из голоса (INTEGRATION.md 1.2) */
export function TaskEditorContainer(_props: TaskEditorContainerProps) {
  return null;
}
