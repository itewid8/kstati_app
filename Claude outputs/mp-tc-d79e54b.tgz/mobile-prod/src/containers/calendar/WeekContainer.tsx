/** Заглушка потока А: C-Week: WeekScreen, неделя с понедельника s.calendarDate (INTEGRATION.md 1.1) */
export function WeekContainer() {
  return null;
}
