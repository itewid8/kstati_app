/** Заглушка потока А: Вкладка «Дела» в виде календаря: выбирает DayContainer / WeekContainer / MonthContainer / YearContainer по s.tasksView (INTEGRATION.md 1.1, 5.1) */
export function CalendarContainer() {
  return null;
}
