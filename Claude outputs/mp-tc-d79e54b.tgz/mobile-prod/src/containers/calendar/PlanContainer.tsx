import type { ID } from '@/lib/types';

export type PlanContainerProps = { id: ID };

/** Заглушка потока А: C-Plan: сетка плана по дням; при открытии setVoiceParent(id), при уходе null (INTEGRATION.md 1.1) */
export function PlanContainer(_props: PlanContainerProps) {
  return null;
}
