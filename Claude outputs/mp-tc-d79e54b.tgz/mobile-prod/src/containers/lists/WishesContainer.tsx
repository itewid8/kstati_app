/** Заглушка потока Г: C-Wishes (INTEGRATION.md 1.4). Подарки чужих хотелок — только при s.serverApi >= 2 */
export function WishesContainer() {
  return null;
}
