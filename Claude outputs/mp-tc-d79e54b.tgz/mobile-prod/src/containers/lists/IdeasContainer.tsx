/** Заглушка потока Г: C-Ideas (INTEGRATION.md 1.4). Архив тем — только при s.serverApi >= 2 */
export function IdeasContainer() {
  return null;
}
