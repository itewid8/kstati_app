// TODO(Г): тап по событию wish.* открывает хотелки ВЛАДЕЛЬЦА хотелки, а не автора события: с API 2 автор подарка —
// даритель, владелец — в scope «u:<ownerId>». Нет владельца в событии — найти хотелку в хранилище по itemId.
// Готовая функция: wishOwnerOf(event, s.wishes) из src/adapters/common/people.ts → setWishPerson(owner) + nav.tab('wishes').

/** Заглушка потока Г: C-Activity: лента; при открытии fetchActivity(true), при уходе markActivitySeen() (INTEGRATION.md 1.4) */
export function ActivityContainer() {
  return null;
}
