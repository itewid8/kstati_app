/** Заглушка потока Г: C-List: вкладка «Дела» списком (s.tasksView === 'list'); нет группы — Redirect на /onboarding (INTEGRATION.md 1.4) */
export function TasksListContainer() {
  return null;
}
