/** Заглушка потока В: Голосовые окна поверх всех экранов (C-Voice, C-AskDelete, C-AskMove, C-AskWeek, C-AskWeekend, ошибки) по s.voice и s.card (INTEGRATION.md 1.3) */
export function VoiceHost() {
  return null;
}
