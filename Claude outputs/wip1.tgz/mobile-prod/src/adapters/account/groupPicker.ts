/** Окно выбора группы: мои группы, текущая отмечена */
import { CATEGORY_LABEL } from '@/lib/types';
import type { PickerGroup } from '@/screens/account/GroupPickerSheet';
import { upper } from '../common/ru';
import type { Snapshot } from '../snapshot';

export function groupPickerRows(s: Pick<Snapshot, 'groups' | 'currentGroupId'>): PickerGroup[] {
  return s.groups.map((g) => ({
    id: g.id,
    name: g.name,
    meta: `${upper(CATEGORY_LABEL[g.category])} · ${g.memberIds.length}`,
    current: g.id === s.currentGroupId,
  }));
}
