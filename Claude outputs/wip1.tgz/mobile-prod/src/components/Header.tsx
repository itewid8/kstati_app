import { useRouter } from 'expo-router';
import { StyleSheet, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { TopBar, size as S, space, useTheme } from '@/ui';

/** Шапка вложенного экрана (как в окнах редактирования): «назад» 40×40 и подпись заглавными */
export const BackHeader = ({ title }: { title: string }) => {
  const { c } = useTheme();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  return (
    <View style={[styles.wrap, { paddingTop: insets.top + S.topBarTop, backgroundColor: c.bg }]}>
      <TopBar lead={{ kind: 'back', label: title.toLocaleUpperCase('ru-RU'), onBack: () => router.back() }} />
    </View>
  );
};

const styles = StyleSheet.create({
  wrap: { paddingHorizontal: space.side, paddingBottom: 12 },
});
