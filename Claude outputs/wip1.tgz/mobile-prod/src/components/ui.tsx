/**
 * Простые элементы для экранов без макета (вход, онбординг, профиль, напоминания, окно групп) — в стиле «Инструмент»:
 * квадратные углы, рамки 1.5px, Geist / Geist Mono, цвета из useTheme() (src/ui). Подписи кнопок, чипов и секций —
 * моноширинным заглавными. API прежний — экраны перешли на новый вид без правок.
 */
import React, { forwardRef, useEffect, useRef, useState } from 'react';
import {
  Platform,
  Pressable,
  StyleSheet,
  Text,
  TextInput,
  View,
  type PressableProps,
  type StyleProp,
  type TextInputProps,
  type TextProps,
  type TextStyle,
  type ViewStyle,
} from 'react-native';
import { Checkbox as UiCheckbox, Marquee, fonts, size as S, space, type as UT, useTheme } from '@/ui';

const upper = (s: string) => s.toLocaleUpperCase('ru-RU');

/* ---------- Текст ---------- */

type TProps = TextProps & {
  variant?: 'title' | 'body' | 'caption' | 'label';
  weight?: 'regular' | 'medium' | 'semibold';
  mono?: boolean;
  muted?: boolean;
  danger?: boolean;
  color?: string;
};

const SIZE = { title: 22, body: 16, caption: 13, label: 12 } as const;
const SANS = { regular: fonts.sans400, medium: fonts.sans500, semibold: fonts.sans600 } as const;

/** Только текст и числа — без вложенных <Text> и элементов */
const isPlainText = (node: React.ReactNode): boolean =>
  typeof node === 'string' || typeof node === 'number' || (Array.isArray(node) && node.every((n) => typeof n === 'string' || typeof n === 'number'));

export function T({ variant = 'body', weight = 'regular', mono, muted, danger, color, style, ...rest }: TProps) {
  const { c } = useTheme();
  const fs = SIZE[variant];
  const s: TextStyle = {
    fontFamily: mono ? fonts.mono400 : variant === 'title' ? fonts.sans700 : SANS[weight],
    fontSize: fs,
    lineHeight: Math.round(fs * 1.4),
    color: color ?? (danger ? c.red : muted ? c.muted : c.text),
    ...(variant === 'title' ? { letterSpacing: -0.66 } : null),
  };
  // Одна строка, которая не влезает, бежит по кругу (как во всех новых экранах)
  if (rest.numberOfLines === 1 && !rest.onPress && isPlainText(rest.children)) {
    return (
      <Marquee style={[s, style]} accessibilityLabel={rest.accessibilityLabel} testID={rest.testID}>
        {rest.children}
      </Marquee>
    );
  }
  return <Text {...rest} style={[s, style]} />;
}

/* ---------- Кнопки ---------- */

type BtnProps = Omit<PressableProps, 'style'> & {
  title: string;
  /** primary — заливка цветом текста; outline — панель в рамке; text — без рамки */
  kind?: 'primary' | 'outline' | 'text';
  /** Удаление: красная рамка и текст */
  danger?: boolean;
  color?: string;
  style?: StyleProp<ViewStyle>;
};

export function Button({ title, kind = 'primary', danger, color, style, disabled, ...rest }: BtnProps) {
  const { c } = useTheme();
  const filled = kind === 'primary' && !danger;
  const framed = kind !== 'text';
  const ink = color ?? (danger ? c.red : filled ? c.bg : c.text);
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityLabel={title}
      accessibilityState={{ disabled: !!disabled }}
      hitSlop={framed ? undefined : 8}
      disabled={disabled}
      style={({ pressed }) => [
        styles.button,
        framed && styles.framed,
        framed && {
          borderColor: danger ? c.red : c.border,
          backgroundColor: filled ? c.text : danger ? c.bg : c.panel,
        },
        !framed && styles.textButton,
        { opacity: disabled ? 0.4 : pressed ? 0.7 : 1 },
        style,
      ]}
      {...rest}
    >
      <Text numberOfLines={1} style={[UT.action, { color: ink }]}>
        {upper(title)}
      </Text>
    </Pressable>
  );
}

/* ---------- Чип ---------- */

export function Chip({
  label,
  selected,
  onPress,
  style,
}: {
  label: string;
  selected?: boolean;
  onPress?: () => void;
  style?: StyleProp<ViewStyle>;
}) {
  const { c } = useTheme();
  return (
    <Pressable
      accessibilityRole="button"
      accessibilityState={{ selected: !!selected }}
      accessibilityLabel={label}
      onPress={onPress}
      style={({ pressed }) => [
        styles.chip,
        { borderColor: c.border, backgroundColor: selected ? c.text : c.panel, opacity: pressed ? 0.7 : 1 },
        style,
      ]}
    >
      <Text numberOfLines={1} style={[selected ? styles.chipStrong : styles.chipLabel, { color: selected ? c.bg : c.text }]}>
        {upper(label)}
      </Text>
    </Pressable>
  );
}

/* ---------- Переключатель ---------- */

/** Переключатель 48×26 (как в настройках C-Settings): включён — квадрат справа и красная точка, выключен — квадрат слева */
export function Toggle({ value, onValueChange }: { value: boolean; onValueChange: (v: boolean) => void }) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={() => onValueChange(!value)}
      hitSlop={10}
      accessibilityRole="switch"
      accessibilityState={{ checked: value }}
      style={[styles.track, { borderColor: c.border, backgroundColor: c.bg }, !value && styles.trackOff]}
    >
      {value ? <View style={[styles.dot, { backgroundColor: c.red, boxShadow: `0 0 6px ${c.glow}` }]} /> : null}
      <View style={[styles.knob, { backgroundColor: value ? c.text : c.muted }]} />
    </Pressable>
  );
}

/* ---------- Галочка ---------- */

export function Checkbox({ checked, onPress }: { checked: boolean; onPress: () => void }) {
  return <UiCheckbox checked={checked} onPress={onPress} accessibilityLabel={checked ? 'Снять отметку' : 'Отметить'} />;
}

/* ---------- Поле ввода ---------- */

/** Цвет выделения текста: полупрозрачный, чтобы выделенные буквы оставались видны */
export const selectionTint = (text: string) => `${text}40`;

/** Подпись поля моноширинным заглавными */
function FieldLabel({ label }: { label: string }) {
  const { c } = useTheme();
  return <Text style={[UT.fieldLabel, { color: c.muted }]}>{upper(label)}</Text>;
}

/**
 * Поле ввода. Текст живёт в самом поле (полуконтролируемо): при каждом нажатии мы не переписываем
 * его обратно из состояния. Иначе на Android после выделения и удаления курсор прыгал в начало
 * и буквы шли задом наперёд. Если значение поменяли снаружи (или обработчик поправил ввод) —
 * поле пересоздаётся с новым текстом и, если было в фокусе, остаётся в фокусе.
 */
export const Field = forwardRef<TextInput, TextInputProps & { label?: string; code?: boolean }>(function Field(
  { label, code, style, value, defaultValue, onChangeText, onFocus, onBlur, autoFocus, ...rest },
  ref,
) {
  const { c } = useTheme();
  const last = useRef(value ?? defaultValue ?? '');
  const focused = useRef(false);
  const [rev, setRev] = useState(0);

  useEffect(() => {
    if (code) return;
    if (value !== undefined && value !== last.current) {
      last.current = value;
      setRev((r) => r + 1);
    }
  }, [value, code]);

  const frame = { backgroundColor: c.panel, borderColor: c.border };

  // Код: всегда заглавными. Поле обычное управляемое (без пересоздания — клавиатура не прыгает),
  // а подсказки и автозамена выключены: иначе клавиатура Android дублирует буквы при замене на заглавные
  if (code) {
    return (
      <View style={styles.fieldWrap}>
        {label ? <FieldLabel label={label} /> : null}
        <TextInput
          ref={ref}
          value={(value ?? '').toUpperCase()}
          onChangeText={(t) => onChangeText?.(t.toUpperCase())}
          onFocus={onFocus}
          onBlur={onBlur}
          autoFocus={autoFocus}
          autoCapitalize="characters"
          autoCorrect={false}
          spellCheck={false}
          autoComplete="off"
          placeholderTextColor={c.muted}
          selectionColor={selectionTint(c.text)}
          selectionHandleColor={c.text}
          cursorColor={c.text}
          {...rest}
          {...(Platform.OS === 'android' && !rest.keyboardType && { keyboardType: 'visible-password' as const })}
          style={[styles.field, frame, styles.fieldCode, { color: c.text }, style]}
        />
      </View>
    );
  }

  return (
    <View style={styles.fieldWrap}>
      {label ? <FieldLabel label={label} /> : null}
      <TextInput
        key={rev}
        ref={ref}
        defaultValue={value ?? defaultValue}
        autoFocus={rev > 0 ? focused.current : autoFocus}
        onChangeText={(t) => {
          last.current = t;
          onChangeText?.(t);
        }}
        onFocus={(e) => {
          focused.current = true;
          onFocus?.(e);
        }}
        onBlur={(e) => {
          focused.current = false;
          onBlur?.(e);
        }}
        // Пароли и почта: на iPhone по умолчанию первая буква заглавная и включена автозамена —
        // поле отправляло «Parol» вместо «parol». Для паролей выключаем всё это всегда.
        {...(rest.secureTextEntry || rest.keyboardType === 'email-address'
          ? { autoCapitalize: 'none' as const, autoCorrect: false, spellCheck: false, smartInsertDelete: false }
          : null)}
        placeholderTextColor={c.muted}
        selectionColor={selectionTint(c.text)}
        selectionHandleColor={c.text}
        cursorColor={c.text}
        style={[styles.field, frame, styles.fieldSans, { color: c.text }, style]}
        {...rest}
      />
    </View>
  );
});

/* ---------- Разделитель и строка ---------- */

export function Divider({ inset = 0 }: { inset?: number }) {
  const { c } = useTheme();
  return <View style={{ height: S.hairline, backgroundColor: c.hair, marginLeft: inset }} />;
}

/** Строка настроек / выбора: подпись слева, значение справа моноширинным */
export function ListRow({
  label,
  value,
  onPress,
  danger,
  right,
  mono,
}: {
  label: string;
  value?: string;
  onPress?: () => void;
  danger?: boolean;
  right?: React.ReactNode;
  mono?: boolean;
}) {
  const { c } = useTheme();
  return (
    <Pressable
      onPress={onPress}
      disabled={!onPress}
      accessibilityRole={onPress ? 'button' : undefined}
      style={({ pressed }) => [styles.listRow, { backgroundColor: pressed ? c.panel : 'transparent' }]}
    >
      <Marquee style={[UT.rowTitle, styles.listLabel, !value && styles.grow, { color: danger ? c.red : c.text }]}>{label}</Marquee>
      {value ? (
        <Marquee style={[mono ? UT.fieldValue : UT.rowTitle, styles.listValue, { color: c.muted }]}>{value}</Marquee>
      ) : null}
      {right}
    </Pressable>
  );
}

export function SectionLabel({ children }: { children: React.ReactNode }) {
  const { c } = useTheme();
  return (
    <Text style={[UT.section, styles.section, { color: c.muted }]}>
      {typeof children === 'string' ? upper(children) : children}
    </Text>
  );
}

const styles = StyleSheet.create({
  button: { height: S.row, paddingHorizontal: 16, alignItems: 'center', justifyContent: 'center' },
  framed: { borderWidth: S.border },
  textButton: { paddingHorizontal: 4 },
  chip: { height: 32, borderWidth: S.border, paddingHorizontal: 10, alignItems: 'center', justifyContent: 'center' },
  chipLabel: { fontFamily: fonts.mono400, fontSize: 9.5, letterSpacing: 0.38 },
  chipStrong: { fontFamily: fonts.mono600, fontSize: 9.5, letterSpacing: 0.38 },
  track: { width: 48, height: 26, borderWidth: S.border, flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between' },
  trackOff: { justifyContent: 'flex-start' },
  dot: { marginLeft: 7, width: 7, height: 7, borderRadius: 4 },
  knob: { width: 22, height: 22 },
  fieldWrap: { gap: 6 },
  field: { height: S.row, borderWidth: S.border, paddingHorizontal: 12 },
  fieldSans: { fontFamily: fonts.sans400, fontSize: 15 },
  fieldCode: { fontFamily: fonts.mono500, fontSize: 13, letterSpacing: 1.3 },
  listRow: { minHeight: S.row, paddingHorizontal: space.side, flexDirection: 'row', alignItems: 'center', gap: 12 },
  listLabel: { flexShrink: 0 },
  grow: { flexGrow: 1, flexShrink: 1 },
  listValue: { flex: 1, textAlign: 'right' },
  section: { paddingHorizontal: space.side, paddingTop: 20, paddingBottom: 6 },
});
