package expo.modules.kstatiwidget

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.res.Configuration
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.util.Log
import android.util.SizeF
import android.view.View
import android.widget.RemoteViews
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.Calendar
import java.util.Locale
import java.util.TimeZone
import kotlin.math.floor
import kotlin.math.roundToInt

/**
 * Виджет «Кстати» в стиле приложения («Инструмент»): список в рамке 1.5 с шапкой (группа, сегодня — число в красном
 * квадрате), строки с полосой цвета человека, названием и временем Geist Mono справа, кнопка REC.
 * Рисуется разметкой Android (RemoteViews), а не картинкой: раскладку по настоящей рамке виджета делает рабочий стол.
 *
 * Данные пишет приложение (src/lib/widgetSync.ts, формат — src/lib/widgetData.ts) в папку приложения:
 *   widget.json        — { v: 2, at, dark, groups: [{ id, name }], items: [{ id, occ, g, title, date, time, until, c }] }
 *   widget-prefs.json  — { "default": настройки, "<id виджета>": настройки } — { mic, micTone, bg, opacity, text, time, group }
 * Подписи времени и цвета считаются так же, как whenParts / widgetColors в widgetData.ts — менять вместе.
 * Прошедшие дела виджет отбрасывает сам и перерисовывается к началу ближайшего дела и в полночь.
 */
object KstatiWidget {
  const val ACTION_REFRESH = "expo.modules.kstatiwidget.REFRESH"
  private const val TAG = "KstatiWidget"
  private const val DATA_FILE = "widget.json"
  private const val PREFS_FILE = "widget-prefs.json"
  private const val PREFS_DEFAULT = "default"
  private const val SCHEME = "kstatiapp"
  private const val DAY_MS = 86_400_000L

  // Коды PendingIntent: открыть дела, запись, строки дел (у каждой строки свой адрес)
  private const val REQ_OPEN = 1
  private const val REQ_REC = 2
  private const val REQ_ITEM = 100

  /** Цвет в светлой и тёмной теме телефона: на Android 12+ система сама берёт нужный, без перерисовки */
  private data class Ink(val day: Int, val night: Int) {
    fun at(night: Boolean) = if (night) this.night else day
    fun alpha(a: Double) = Ink(withAlpha(day, a), withAlpha(night, a))
  }

  private data class Item(
    val id: String,
    val occ: String?,
    val group: String,
    val title: String,
    val date: String,
    val time: String?,
    val until: Long,
    val strip: List<Ink>,
  )

  private data class Snapshot(val items: List<Item>, val dark: Boolean?, val groups: Map<String, String>)

  private data class Prefs(
    val mic: Boolean,
    val micTone: String,
    val bg: String,
    val opacity: Double,
    val text: String,
    val time: String,
    val group: String?,
  )

  /** Палитра приложения (src/ui/tokens.ts) */
  private class Palette(val bg: Int, val panel: Int, val border: Int, val hair: Int, val text: Int, val muted: Int, val red: Int)

  private class Colors(
    val card: Ink,
    val panel: Ink,
    val border: Ink,
    val hair: Ink,
    val headBg: Ink,
    val headInk: Ink,
    val today: Ink,
    val todayInk: Ink,
    val title: Ink,
    val day: Ink,
    val time: Ink,
    val empty: Ink,
    val recFill: Ink,
    val recBorder: Ink,
    val recDot: Ink,
    val recInk: Ink,
    val showMic: Boolean,
  )

  private val LIGHT = Palette(
    bg = 0xFFE7E6E1.toInt(),
    panel = 0xFFF4F3EF.toInt(),
    border = 0xFF161616.toInt(),
    hair = 0xFFCFCEC8.toInt(),
    text = 0xFF111111.toInt(),
    muted = 0xFF5E5E58.toInt(),
    red = 0xFFE0281E.toInt(),
  )
  private val DARK = Palette(
    bg = 0xFF0B0B0B.toInt(),
    panel = 0xFF151515.toInt(),
    border = 0xFF2E2E2E.toInt(),
    hair = 0xFF222222.toInt(),
    text = 0xFFF2F2F0.toInt(),
    muted = 0xFF7C7C78.toInt(),
    red = 0xFFFF3B30.toInt(),
  )
  /** Белые цифры в красном квадрате «сегодня» — как в C-Week */
  private val TODAY_INK = 0xFFFFFFFF.toInt()

  private enum class Kind { MIC, ROW, TALL }

  /**
   * Раскладки и размер (dp), начиная с которого каждая подходит:
   *   только REC · список слева и REC справа (шапка — от 90 dp высоты) · список сверху и REC снизу полосой;
   *   inline — «название … время» в строку, иначе название, под ним время.
   */
  private class Layout(val kind: Kind, val inline: Boolean, val header: Boolean, val w: Float, val h: Float)

  private val LAYOUTS = listOf(
    Layout(Kind.MIC, inline = false, header = false, w = 40f, h = 40f),
    Layout(Kind.ROW, inline = false, header = false, w = 110f, h = 40f),
    Layout(Kind.ROW, inline = true, header = false, w = 180f, h = 40f),
    Layout(Kind.ROW, inline = true, header = true, w = 200f, h = 90f),
    Layout(Kind.TALL, inline = false, header = true, w = 110f, h = 150f),
    Layout(Kind.TALL, inline = true, header = true, w = 180f, h = 150f),
  )

  private val WD = arrayOf("ПН", "ВТ", "СР", "ЧТ", "ПТ", "СБ", "ВС")
  private val MON = arrayOf("ЯНВ", "ФЕВ", "МАР", "АПР", "МАЙ", "ИЮН", "ИЮЛ", "АВГ", "СЕН", "ОКТ", "НОЯ", "ДЕК")

  fun updateAll(context: Context) {
    val manager = AppWidgetManager.getInstance(context)
    val ids = manager.getAppWidgetIds(ComponentName(context, KstatiWidgetProvider::class.java))
    val snap = readSnapshot(context)
    val prefs = readJson(context, PREFS_FILE)
    for (id in ids) draw(context, manager, id, snap, prefs)
    scheduleNext(context, snap, ids.isNotEmpty())
  }

  fun update(context: Context, widgetId: Int) {
    val snap = readSnapshot(context)
    draw(context, AppWidgetManager.getInstance(context), widgetId, snap, readJson(context, PREFS_FILE))
    scheduleNext(context, snap, true)
  }

  fun cancelRefresh(context: Context) {
    context.getSystemService(AlarmManager::class.java)?.cancel(refreshIntent(context))
  }

  /** Виджеты убрали с рабочего стола — их настройки больше не нужны */
  fun forget(context: Context, widgetIds: IntArray) {
    try {
      val all = readJson(context, PREFS_FILE) ?: return
      var changed = false
      for (id in widgetIds) if (all.remove(id.toString()) != null) changed = true
      if (changed) File(context.filesDir, PREFS_FILE).writeText(all.toString())
    } catch (e: Exception) {
      Log.w(TAG, "Настройки виджета не удалены", e)
    }
  }

  /* ---------- рисование ---------- */

  private fun draw(context: Context, manager: AppWidgetManager, widgetId: Int, snap: Snapshot?, prefsAll: JSONObject?) {
    try {
      val prefs = readPrefs(prefsAll, widgetId)
      val night = isNight(context)
      val colors = colors(snap?.dark, prefs)
      val now = System.currentTimeMillis()
      val options = manager.getAppWidgetOptions(widgetId)
      val views = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        // Своя раскладка на каждый размер, который сообщил рабочий стол (обычно вертикальный и горизонтальный экран):
        // число строк считается по настоящей высоте. Размеров нет — раскладки по порогам, система выберет сама
        val sizes = reportedSizes(options)
        if (sizes.isNotEmpty()) {
          RemoteViews(sizes.associateWith { build(context, bestFit(it), snap, prefs, colors, now, it, night) })
        } else {
          val size = reportedSize(context, options)
          RemoteViews(LAYOUTS.associate { SizeF(it.w, it.h) to build(context, it, snap, prefs, colors, now, size, night) })
        }
      } else {
        val size = reportedSize(context, options)
        build(context, bestFit(size), snap, prefs, colors, now, size, night)
      }
      manager.updateAppWidget(widgetId, views)
    } catch (e: Exception) {
      Log.w(TAG, "Виджет не нарисован", e)
    }
  }

  private fun build(
    context: Context,
    chosen: Layout,
    snap: Snapshot?,
    p: Prefs,
    c: Colors,
    now: Long,
    size: SizeF,
    night: Boolean,
  ): RemoteViews {
    // Без REC раскладка «только REC» не нужна — показываем дела
    val layout = if (chosen.kind == Kind.MIC && !c.showMic) Layout(Kind.ROW, false, false, chosen.w, chosen.h) else chosen
    val res = when (layout.kind) {
      Kind.MIC -> R.layout.kstati_widget_mic
      Kind.ROW -> R.layout.kstati_widget_row
      Kind.TALL -> R.layout.kstati_widget_tall
    }
    val v = RemoteViews(context.packageName, res)
    v.ink(android.R.id.background, "setBackgroundColor", c.card, night)
    v.setOnClickPendingIntent(android.R.id.background, open(context, "$SCHEME://tasks", REQ_OPEN))

    if (layout.kind != Kind.MIC) fillBox(context, v, layout, snap, p, c, now, size, night)

    // Видимость задаём всегда явно: при той же раскладке рабочий стол не создаёт виджет заново, а применяет команды
    // к уже показанному — однажды скрытая кнопка без VISIBLE так и осталась бы скрытой
    if (c.showMic) {
      v.setViewVisibility(R.id.kstati_rec, View.VISIBLE)
      v.ink(R.id.kstati_rec_fill, "setBackgroundColor", c.recFill, night)
      v.ink(R.id.kstati_rec_stroke, "setColorFilter", c.recBorder, night)
      v.ink(R.id.kstati_rec_dot, "setColorFilter", c.recDot, night)
      v.ink(R.id.kstati_rec_glow, "setColorFilter", c.recDot, night)
      v.ink(R.id.kstati_rec_label, "setTextColor", c.recInk, night)
      v.setOnClickPendingIntent(R.id.kstati_rec, open(context, "$SCHEME://record", REQ_REC))
    } else {
      v.setViewVisibility(R.id.kstati_rec, View.GONE)
    }
    return v
  }

  /** Список в рамке: шапка (если раскладка с ней) и строки дел; нажатие на строку открывает дело */
  private fun fillBox(
    context: Context,
    v: RemoteViews,
    layout: Layout,
    snap: Snapshot?,
    p: Prefs,
    c: Colors,
    now: Long,
    size: SizeF,
    night: Boolean,
  ) {
    v.ink(R.id.kstati_box_fill, "setBackgroundColor", c.panel, night)
    v.ink(R.id.kstati_box_stroke, "setColorFilter", c.border, night)
    v.setOnClickPendingIntent(R.id.kstati_box, open(context, "$SCHEME://tasks", REQ_OPEN))

    val groups = snap?.groups ?: emptyMap()
    // Группу удалили или из неё вышли — показываем все
    val group = p.group?.takeIf { groups.containsKey(it) }
    val today = localIso(now)

    if (layout.header) {
      v.setViewVisibility(R.id.kstati_header, View.VISIBLE)
      v.ink(R.id.kstati_header, "setBackgroundColor", c.headBg, night)
      val label = group?.let { groups[it] }?.uppercase(Locale("ru", "RU")) ?: "ВСЕ ГРУППЫ"
      v.setTextViewText(R.id.kstati_header_label, label)
      v.ink(R.id.kstati_header_label, "setTextColor", c.headInk, night)
      v.setTextViewText(R.id.kstati_header_weekday, WD[weekdayIndex(today)])
      v.ink(R.id.kstati_header_weekday, "setTextColor", c.headInk, night)
      v.setTextViewText(R.id.kstati_header_day, today.substring(8, 10))
      v.ink(R.id.kstati_header_day, "setBackgroundColor", c.today, night)
      v.ink(R.id.kstati_header_day, "setTextColor", c.todayInk, night)
    } else {
      v.setViewVisibility(R.id.kstati_header, View.GONE)
    }

    v.removeAllViews(R.id.kstati_list)
    val rows = visible(snap?.items ?: emptyList(), now, rowCount(context, layout, size, c.showMic), group)
    if (rows.isEmpty()) {
      val empty = RemoteViews(context.packageName, R.layout.kstati_row_empty)
      empty.ink(R.id.kstati_empty, "setTextColor", c.empty, night)
      v.addView(R.id.kstati_list, empty)
    }
    rows.forEachIndexed { i, x ->
      val row = RemoteViews(context.packageName, if (layout.inline) R.layout.kstati_row_inline else R.layout.kstati_row_stacked)
      // Разделитель 1 между строками; под шапкой и у первой строки без шапки — нет
      if (i == 0) {
        row.setViewVisibility(R.id.kstati_divider, View.GONE)
      } else {
        row.setViewVisibility(R.id.kstati_divider, View.VISIBLE)
        row.ink(R.id.kstati_divider, "setBackgroundColor", c.hair, night)
      }
      val a = x.strip.getOrNull(0)
      val b = x.strip.getOrNull(1)
      if (a != null) row.ink(R.id.kstati_strip_a, "setBackgroundColor", a, night)
      if (b != null) {
        row.setViewVisibility(R.id.kstati_strip_b, View.VISIBLE)
        row.ink(R.id.kstati_strip_b, "setBackgroundColor", b, night)
      } else {
        row.setViewVisibility(R.id.kstati_strip_b, View.GONE)
      }
      row.setTextViewText(R.id.kstati_title, x.title)
      row.ink(R.id.kstati_title, "setTextColor", c.title, night)
      val (day, time) = whenParts(x.date, x.time, today)
      if (day == null) {
        row.setViewVisibility(R.id.kstati_day, View.GONE)
      } else {
        row.setViewVisibility(R.id.kstati_day, View.VISIBLE)
        row.setTextViewText(R.id.kstati_day, day)
        row.ink(R.id.kstati_day, "setTextColor", c.day, night)
      }
      row.setTextViewText(R.id.kstati_time, time)
      row.ink(R.id.kstati_time, "setTextColor", c.time, night)
      row.setOnClickPendingIntent(R.id.kstati_row, open(context, itemUri(x), REQ_ITEM + i))
      v.addView(R.id.kstati_list, row)
    }
  }

  /** kstatiapp://widget/open?id=…&occ=… — экран app/widget/open.tsx откроет дело (или план) */
  private fun itemUri(x: Item): String {
    val b = Uri.Builder().scheme(SCHEME).authority("widget").appendPath("open").appendQueryParameter("id", x.id)
    if (x.occ != null) b.appendQueryParameter("occ", x.occ)
    return b.build().toString()
  }

  /**
   * Сколько строк дел поместится. Высоту знаем только со слов рабочего стола (бывает больше настоящей на несколько
   * процентов), поэтому считаем с запасом: лишняя строка не должна выглядывать обрезанной
   */
  private fun rowCount(context: Context, layout: Layout, size: SizeF, showMic: Boolean): Int {
    val scale = maxOf(1f, context.resources.configuration.fontScale)
    val pad = if (layout.kind == Kind.TALL) 2 * 10f else 2 * 8f
    val head = if (layout.header) 22f * scale else 0f
    val rec = if (layout.kind == Kind.TALL && showMic) 40f + 6f else 0f
    val avail = size.height * 0.94f - pad - 2 * 1.5f - head - rec
    // Строка и разделитель над ней (у первой разделителя нет — отсюда +1)
    val rowH = (if (layout.inline) 30f else 37f) * scale + 1f
    return floor((avail + 1f) / rowH).toInt().coerceIn(1, 10)
  }

  /** Как система выбирает раскладку на Android 12+: из помещающихся — ближайшая по размеру; если ни одна — самая маленькая */
  private fun bestFit(size: SizeF): Layout {
    var best: Layout? = null
    var bestD = Float.MAX_VALUE
    for (l in LAYOUTS) {
      if (l.w > size.width + 0.5f || l.h > size.height + 0.5f) continue
      val dw = size.width - l.w
      val dh = size.height - l.h
      val d = dw * dw + dh * dh
      if (d < bestD) {
        best = l
        bestD = d
      }
    }
    return best ?: LAYOUTS.first()
  }

  /** Все размеры (dp), которые сообщил рабочий стол (Android 12+), без повторов и пустых */
  @Suppress("DEPRECATION")
  private fun reportedSizes(options: Bundle): List<SizeF> {
    if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return emptyList()
    val sizes = options.getParcelableArrayList<SizeF>(AppWidgetManager.OPTION_APPWIDGET_SIZES) ?: return emptyList()
    return sizes.filter { it.width > 0f && it.height > 0f }.distinct().take(16)
  }

  /** Размер виджета (dp) со слов рабочего стола для текущей ориентации экрана */
  private fun reportedSize(context: Context, options: Bundle): SizeF {
    val portrait = context.resources.configuration.orientation != Configuration.ORIENTATION_LANDSCAPE
    val sizes = reportedSizes(options)
    if (sizes.isNotEmpty()) {
      // Обычно два размера: для вертикального экрана (уже и выше) и для горизонтального
      return if (portrait) sizes.minBy { it.width / it.height } else sizes.maxBy { it.width / it.height }
    }
    val w = options.getInt(if (portrait) AppWidgetManager.OPTION_APPWIDGET_MIN_WIDTH else AppWidgetManager.OPTION_APPWIDGET_MAX_WIDTH)
    val h = options.getInt(if (portrait) AppWidgetManager.OPTION_APPWIDGET_MAX_HEIGHT else AppWidgetManager.OPTION_APPWIDGET_MIN_HEIGHT)
    return SizeF(if (w > 0) w.toFloat() else 180f, if (h > 0) h.toFloat() else 110f)
  }

  private fun open(context: Context, uri: String, code: Int): PendingIntent {
    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(uri))
      .setPackage(context.packageName)
      .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    return PendingIntent.getActivity(context, code, intent, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
  }

  /** Цвет с учётом темы: Android 12+ — пара цветов, система выбирает по теме сама; раньше — по теме сейчас */
  private fun RemoteViews.ink(id: Int, method: String, c: Ink, night: Boolean) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
      setColorInt(id, method, c.day, c.night)
    } else {
      setInt(id, method, c.at(night))
    }
  }

  /* ---------- цвета (как widgetColors в src/lib/widgetData.ts) ---------- */

  /**
   * «Как в теме» — тема приложения, а если там «система» — тема телефона (пара: светлая тема телефона / тёмная).
   * Фон «светлый» — светлая палитра; названия и время «светлые» — светлые буквы (из тёмной палитры);
   * REC «светлая» — светлая кнопка. Время «как в теме» — цвет текста, день перед ним — приглушённый.
   * Непрозрачность — у подложки и заливки списка; рамки, шапка и буквы остаются чёткими
   */
  private fun colors(dark: Boolean?, p: Prefs): Colors {
    val auto = Pair(if (dark == true) DARK else LIGHT, if (dark == false) LIGHT else DARK)
    fun look(tone: String): Pair<Palette, Palette> = when (tone) {
      "light" -> Pair(LIGHT, LIGHT)
      "dark" -> Pair(DARK, DARK)
      else -> auto
    }
    val bg = look(p.bg)
    fun ink(tone: String): Pair<Palette, Palette> = when (tone) {
      "light" -> Pair(DARK, DARK)
      "dark" -> Pair(LIGHT, LIGHT)
      else -> bg
    }
    val rec = look(p.micTone)
    val time = ink(p.time)
    fun of(set: Pair<Palette, Palette>, f: (Palette) -> Int) = Ink(f(set.first), f(set.second))
    return Colors(
      card = of(bg) { it.bg }.alpha(p.opacity),
      panel = of(bg) { it.panel }.alpha(p.opacity),
      border = of(bg) { it.border },
      hair = of(bg) { it.hair },
      headBg = of(bg) { it.text },
      headInk = of(bg) { it.bg },
      today = of(bg) { it.red },
      todayInk = Ink(TODAY_INK, TODAY_INK),
      title = of(ink(p.text)) { it.text },
      day = if (p.time == "auto") of(bg) { it.muted } else of(time) { it.text },
      time = of(time) { it.text },
      empty = of(bg) { it.muted },
      recFill = of(rec) { it.panel },
      recBorder = of(rec) { it.border },
      recDot = of(rec) { it.red },
      recInk = of(rec) { it.text },
      showMic = p.mic,
    )
  }

  private fun withAlpha(color: Int, a: Double): Int {
    val alpha = (a.coerceIn(0.0, 1.0) * 255).roundToInt()
    return (color and 0x00FFFFFF) or (alpha shl 24)
  }

  private fun isNight(context: Context) =
    (context.resources.configuration.uiMode and Configuration.UI_MODE_NIGHT_MASK) == Configuration.UI_MODE_NIGHT_YES

  /* ---------- дела и подписи (как visibleAt / whenParts в widgetData.ts) ---------- */

  /** Первые n ещё не прошедших дел группы (или всех); у серии — только ближайший раз */
  private fun visible(items: List<Item>, now: Long, n: Int, group: String?): List<Item> {
    val seen = HashSet<String>()
    val out = ArrayList<Item>()
    for (x in items) {
      if (out.size >= n) break
      if (x.until <= now || (group != null && x.group != group) || !seen.add(x.id)) continue
      out.add(x)
    }
    return out
  }

  /**
   * Подпись дня (приглушённая, может не быть) и время справа:
   * сегодня — «19:00» / «—»; завтра — «ЗАВТРА» + время или просто «ЗАВТРА»; до 6 дней — «СБ 10»; дальше — «17 ОКТ»
   */
  private fun whenParts(date: String, time: String?, today: String): Pair<String?, String> {
    val diff = dayNo(date) - dayNo(today)
    if (diff <= 0L) return Pair(null, time ?: "—")
    val day = when {
      diff == 1L -> "ЗАВТРА"
      diff <= 6L -> "${WD[weekdayIndex(date)]} ${date.substring(8, 10)}"
      else -> "${date.substring(8, 10).toInt()} ${MON[(date.substring(5, 7).toInt() - 1).coerceIn(0, 11)]}"
    }
    return if (time != null) Pair(day, time) else Pair(null, day)
  }

  private fun parts(iso: String): IntArray {
    val p = iso.split("-")
    return intArrayOf(p.getOrNull(0)?.toIntOrNull() ?: 1970, p.getOrNull(1)?.toIntOrNull() ?: 1, p.getOrNull(2)?.toIntOrNull() ?: 1)
  }

  private fun utcDay(iso: String): Calendar {
    val p = parts(iso)
    return Calendar.getInstance(TimeZone.getTimeZone("UTC")).apply {
      clear()
      set(p[0], p[1] - 1, p[2])
    }
  }

  /** Номер дня от 1970-01-01 — разница дат без часовых поясов и перехода на летнее время */
  private fun dayNo(iso: String): Long = utcDay(iso).timeInMillis / DAY_MS

  /** 0 = пн … 6 = вс */
  private fun weekdayIndex(iso: String): Int = (utcDay(iso).get(Calendar.DAY_OF_WEEK) + 5) % 7

  private fun localIso(ms: Long): String {
    val c = Calendar.getInstance().apply { timeInMillis = ms }
    return String.format(Locale.US, "%04d-%02d-%02d", c.get(Calendar.YEAR), c.get(Calendar.MONTH) + 1, c.get(Calendar.DAY_OF_MONTH))
  }

  /* ---------- перерисовка по времени ---------- */

  /** Будильник (неточный, без пробуждения телефона) к началу ближайшего дела и к полуночи — чтобы прошедшее исчезало */
  private fun scheduleNext(context: Context, snap: Snapshot?, any: Boolean) {
    val alarms = context.getSystemService(AlarmManager::class.java) ?: return
    val pi = refreshIntent(context)
    alarms.cancel(pi)
    if (!any) return
    val now = System.currentTimeMillis()
    val midnight = Calendar.getInstance().apply {
      timeInMillis = now
      add(Calendar.DAY_OF_MONTH, 1)
      set(Calendar.HOUR_OF_DAY, 0)
      set(Calendar.MINUTE, 0)
      set(Calendar.SECOND, 5)
      set(Calendar.MILLISECOND, 0)
    }.timeInMillis
    val next = snap?.items?.asSequence()?.map { it.until }?.filter { it > now }?.minOrNull()
    val at = if (next != null && next < midnight) next + 1000 else midnight
    alarms.set(AlarmManager.RTC, at, pi)
  }

  private fun refreshIntent(context: Context): PendingIntent =
    PendingIntent.getBroadcast(
      context,
      0,
      Intent(context, KstatiWidgetProvider::class.java).setAction(ACTION_REFRESH),
      PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE,
    )

  /* ---------- файлы ---------- */

  private fun readJson(context: Context, name: String): JSONObject? = try {
    val f = File(context.filesDir, name)
    if (f.exists()) JSONObject(f.readText()) else null
  } catch (e: Exception) {
    null
  }

  private fun JSONObject.str(key: String): String? = if (has(key) && !isNull(key)) optString(key) else null

  private fun color(hex: String?, fallback: Int): Int = try {
    if (hex == null) fallback else Color.parseColor(hex)
  } catch (e: IllegalArgumentException) {
    fallback
  }

  /** [["#светлая", "#тёмная"], …] — цвет полосы каждого человека в обеих темах */
  private fun strips(arr: JSONArray?): List<Ink> {
    if (arr == null) return emptyList()
    val out = ArrayList<Ink>()
    for (i in 0 until minOf(arr.length(), 2)) {
      val pair = arr.optJSONArray(i) ?: continue
      val day = color(pair.optString(0, ""), LIGHT.muted)
      out.add(Ink(day, color(pair.optString(1, ""), day)))
    }
    return out
  }

  private fun readSnapshot(context: Context): Snapshot? {
    val o = readJson(context, DATA_FILE) ?: return null
    val items = ArrayList<Item>()
    val arr = o.optJSONArray("items")
    if (arr != null) {
      for (i in 0 until arr.length()) {
        val x = arr.optJSONObject(i) ?: continue
        val date = x.str("date") ?: continue
        items.add(
          Item(
            id = x.optString("id"),
            occ = x.str("occ"),
            group = x.optString("g"),
            title = x.optString("title"),
            date = date,
            time = x.str("time"),
            until = x.optLong("until"),
            strip = strips(x.optJSONArray("c")),
          ),
        )
      }
    }
    val groups = LinkedHashMap<String, String>()
    val garr = o.optJSONArray("groups")
    if (garr != null) {
      for (i in 0 until garr.length()) {
        val g = garr.optJSONObject(i) ?: continue
        groups[g.optString("id")] = g.optString("name")
      }
    }
    val dark = if (o.has("dark") && !o.isNull("dark")) o.optBoolean("dark") else null
    return Snapshot(items, dark, groups)
  }

  /** Настройки виджета: свои → общие («default», экран в приложении) → по умолчанию */
  private fun readPrefs(all: JSONObject?, widgetId: Int): Prefs {
    val p = all?.optJSONObject(widgetId.toString()) ?: all?.optJSONObject(PREFS_DEFAULT)
    fun tone(key: String): String = when (val t = p?.optString(key, "auto")) {
      "light", "dark" -> t
      else -> "auto"
    }
    return Prefs(
      mic = p?.optBoolean("mic", true) ?: true,
      micTone = tone("micTone"),
      bg = tone("bg"),
      opacity = (p?.optDouble("opacity", 1.0) ?: 1.0).let { if (it.isNaN()) 1.0 else it.coerceIn(0.0, 1.0) },
      text = tone("text"),
      time = tone("time"),
      group = p?.str("group")?.takeIf { it.isNotEmpty() },
    )
  }
}
