/**
 * Заметка внутри темы (C-Note, src/screens/lists/NoteScreen). Своя — правится по строкам (useNoteEditor), сохраняется
 * сама; очистили и вышли — заметка удаляется. Новая (id NEW_NOTE) появляется в теме topicId с первым словом.
 * Чужая — только читать. «⋯» — быстрые действия (в дела, копия, в тему, удалить).
 */
import { router } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Keyboard } from 'react-native';
import { upper } from '@/adapters/common/ru';
import { uid } from '@/lib/ids';
import { parseNote, isBlankNote } from '@/lib/note';
import { useStore } from '@/lib/store';
import type { ID } from '@/lib/types';
import { NoteScreen } from '@/screens/lists/NoteScreen';
import { NEW_NOTE, nav, signedInOnly, useInsets } from '../common';
import { holdIdea } from '../quick/quickStore';
import { useNoteEditor } from './useNoteEditor';

const back = (topicId: ID | null) => (router.canGoBack() ? router.back() : router.navigate(topicId ? nav.topic(topicId) : nav.tab('ideas')));

export const NoteContainer = signedInOnly(function Note({ id: routeId, topicId: routeTopic }: { id: ID; topicId: ID | null }) {
  // Новая заметка получает id сразу: с первым словом она уже в теме
  const [id] = useState(() => (routeId === NEW_NOTE ? uid() : routeId));
  const idea = useStore((s) => s.ideas.find((x) => x.id === id));
  const meId = useStore((s) => s.me?.id);
  const topicId = idea ? idea.topicId : routeTopic;
  const topicTitle = useStore((s) => (topicId ? s.topics.find((t) => t.id === topicId)?.title : undefined));
  const insets = useInsets();
  const editable = !idea || idea.ownerId === meId;
  const existed = useRef(!!idea);
  if (idea) existed.current = true;

  /** В хранилище (оттуда — на сервер): пустая новая не создаётся, очищенная удаляется */
  const save = useCallback(
    (text: string) => {
      if (!editable) return;
      const st = useStore.getState();
      if (isBlankNote(parseNote(text))) {
        if (st.ideas.some((x) => x.id === id)) st.dropIdea(id);
        return;
      }
      st.putNote(id, topicId, text);
    },
    [editable, id, topicId],
  );
  const ed = useNoteEditor(idea?.text ?? '', save, { focusFirst: !idea });

  // Заметку удалили (быстрые действия, другой телефон) — уходим
  useEffect(() => {
    if (existed.current && !idea) back(topicId);
  }, [idea, topicId]);

  const onDone = useCallback(() => {
    Keyboard.dismiss();
    back(topicId);
  }, [topicId]);
  const onMore = useCallback(() => {
    Keyboard.dismiss();
    ed.flush();
    if (useStore.getState().ideas.some((x) => x.id === id)) holdIdea(id);
  }, [id, ed]);

  const caption = useMemo(() => `ЗАМЕТКА · ${upper(topicTitle ?? 'Без темы')}`, [topicTitle]);

  return (
    <NoteScreen
      caption={caption}
      blocks={ed.blocks}
      editable={editable}
      active={ed.active}
      caret={ed.caret}
      insets={insets}
      onBack={onDone}
      onMore={idea ? onMore : undefined}
      onChangeText={ed.onChangeText}
      onBackspace={ed.onBackspace}
      onToggleCheck={ed.onToggleCheck}
      onFocus={ed.onFocus}
      onTool={ed.onTool}
      onDone={onDone}
    />
  );
});
