/**
 * Запросы к серверу «Кстати». Токен передаётся явно — модуль не знает про хранилище.
 * Ошибки: ApiError — сервер ответил отказом (status, code, message); NetError — нет связи.
 */
import Constants from 'expo-constants';
import { API_URL } from './config';

/** Уровень API, который понимает приложение: сервер включает для него новые поля и виды ответа */
export const API_LEVEL = 2;

const build = String(Constants.expoConfig?.android?.versionCode ?? Constants.expoConfig?.ios?.buildNumber ?? '0');
/** Версия клиента для журнала сервера: «ru.kstati.app/0.1.0(1)» */
export const APP_ID = `ru.kstati.app/${Constants.expoConfig?.version ?? '0'}(${build})`;

export class ApiError extends Error {
  constructor(
    public status: number,
    public code: string,
    message: string,
  ) {
    super(message);
  }
}
export class NetError extends Error {}

/** Текст ошибки для человека */
export const errorText = (e: unknown): string =>
  e instanceof ApiError ? e.message : e instanceof NetError ? 'Нет связи с сервером. Проверьте интернет.' : 'Что-то пошло не так';

export async function request<T = unknown>(
  path: string,
  opts: { method?: 'GET' | 'POST' | 'DELETE'; body?: unknown; token?: string | null; timeoutMs?: number } = {},
): Promise<T> {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), opts.timeoutMs ?? 20_000);
  let res: Response;
  try {
    res = await fetch(`${API_URL}${path}`, {
      method: opts.method ?? (opts.body !== undefined ? 'POST' : 'GET'),
      headers: {
        'x-kstati-api': String(API_LEVEL),
        'x-kstati-app': APP_ID,
        ...(opts.body !== undefined && { 'Content-Type': 'application/json' }),
        // Не Authorization: его перехватывает Яндекс Облако (см. server/src/auth.ts)
        ...(opts.token && { 'X-Kstati-Token': opts.token }),
      },
      body: opts.body !== undefined ? JSON.stringify(opts.body) : undefined,
      signal: ctrl.signal,
    });
  } catch (e) {
    // expo/fetch при отмене по таймеру пишет «Fetch request has been canceled», а не AbortError
    throw new NetError(ctrl.signal.aborted || (e as Error).name === 'AbortError' ? 'timeout' : String((e as Error).message ?? e));
  } finally {
    clearTimeout(timer);
  }
  const text = await res.text().catch(() => '');
  let json: unknown = null;
  try {
    json = text ? JSON.parse(text) : null;
  } catch {
    /* не JSON */
  }
  if (!res.ok) {
    const body = json && typeof json === 'object' ? (json as { error?: unknown; message?: unknown }) : {};
    const code = typeof body.error === 'string' ? body.error : `http_${res.status}`;
    const message = typeof body.message === 'string' ? body.message : `Ошибка сервера (${res.status})`;
    throw new ApiError(res.status, code, message);
  }
  return json as T;
}

/* ---------- операции изменения данных (POST /ops): описаны в ops.ts (без зависимостей от Expo) ---------- */
export { opKey, type Op, type OpResult } from './ops';
