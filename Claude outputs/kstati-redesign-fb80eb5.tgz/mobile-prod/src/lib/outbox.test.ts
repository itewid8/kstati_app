/** Очередь правок: отвергнутая сервером операция не держит очередь, ошибки связи и 5xx — ждут */
import { describe, test } from 'node:test';
import assert from 'node:assert/strict';
import { flushOutbox, type FailKind, type OutboxDeps } from './outbox';

class HttpErr extends Error {
  constructor(public status: number) {
    super(`http ${status}`);
  }
}
const classify = (e: unknown): FailKind =>
  e instanceof HttpErr ? (e.status === 401 ? 'auth' : e.status >= 500 ? 'retry' : 'reject') : 'retry';

type Op = { id: string };

/** Промис отклонён ошибкой, которая проходит check (в шиме node:assert нет rejects) */
async function rejects(p: Promise<unknown>, check: (e: unknown) => boolean = () => true): Promise<void> {
  let error: unknown = null;
  let failed = false;
  try {
    await p;
  } catch (e) {
    failed = true;
    error = e;
  }
  assert.ok(failed, 'ожидалась ошибка');
  assert.ok(check(error), `не та ошибка: ${String(error)}`);
}

/** Очередь в памяти и сервер, который отвергает пачку целиком, если в ней есть плохая операция */
function setup(ops: Op[], fail: (batch: Op[]) => number | null, batchSize = 4) {
  let outbox = [...ops];
  const sent: string[][] = [];
  const rejected: string[] = [];
  const deps: OutboxDeps<Op> = {
    read: () => outbox,
    send: async (batch) => {
      const status = fail(batch);
      if (status) throw new HttpErr(status);
      sent.push(batch.map((o) => o.id));
    },
    remove: (done) => {
      outbox = outbox.filter((o) => !done.includes(o));
    },
    classify,
    onReject: (op) => rejected.push(op.id),
    batchSize,
  };
  return { deps, sent, rejected, outbox: () => outbox };
}

const ops = (n: number): Op[] => Array.from({ length: n }, (_, i) => ({ id: `op${i}` }));

describe('flushOutbox', () => {
  test('400 на пачку: плохая операция находится делением и уходит в карантин, остальные отправлены', async () => {
    const q = setup(ops(10), (b) => (b.some((o) => o.id === 'op5') ? 400 : null));
    await flushOutbox(q.deps);
    assert.deepEqual(q.rejected, ['op5']);
    assert.deepEqual(q.outbox(), []);
    assert.deepEqual(q.sent.flat().sort(), ops(10).map((o) => o.id).filter((id) => id !== 'op5').sort());
    // Порядок отправки сохраняется
    assert.deepEqual(q.sent.flat(), ['op0', 'op1', 'op2', 'op3', 'op4', 'op6', 'op7', 'op8', 'op9']);
  });

  test('409 и 422 — тоже отказ, не вечная очередь', async () => {
    for (const status of [409, 422]) {
      const q = setup(ops(3), (b) => (b.some((o) => o.id === 'op0') ? status : null));
      await flushOutbox(q.deps);
      assert.deepEqual(q.rejected, ['op0']);
      assert.deepEqual(q.outbox(), []);
    }
  });

  test('5xx и нет связи: пачка остаётся в очереди, ошибка пробрасывается (повтор позже)', async () => {
    const q = setup(ops(3), () => 503);
    await rejects(flushOutbox(q.deps), (e: unknown) => e instanceof HttpErr && e.status === 503);
    assert.equal(q.outbox().length, 3);
    assert.deepEqual(q.rejected, []);
    let outbox = ops(2);
    await rejects(
      flushOutbox({
        read: () => outbox,
        send: async () => {
          throw new Error('network');
        },
        remove: (done) => {
          outbox = outbox.filter((o) => !done.includes(o));
        },
        classify,
        onReject: () => {
          throw new Error('связь — не отказ');
        },
      }),
    );
    assert.equal(outbox.length, 2);
  });

  test('401 пробрасывается без деления пачки', async () => {
    let calls = 0;
    const q = setup(ops(8), () => {
      calls++;
      return 401;
    });
    await rejects(flushOutbox(q.deps), (e: unknown) => e instanceof HttpErr && e.status === 401);
    assert.equal(calls, 1);
    assert.equal(q.outbox().length, 8);
  });

  test('операции, добавленные во время отправки, не теряются', async () => {
    let outbox = ops(2);
    const sent: string[] = [];
    await flushOutbox<Op>({
      read: () => outbox,
      send: async (batch) => {
        sent.push(...batch.map((o) => o.id));
        if (batch[0]?.id === 'op0') outbox = [...outbox, { id: 'late' }];
      },
      remove: (done) => {
        outbox = outbox.filter((o) => !done.includes(o));
      },
      classify,
      onReject: () => {},
    });
    assert.deepEqual(sent, ['op0', 'op1', 'late']);
    assert.deepEqual(outbox, []);
  });
});
