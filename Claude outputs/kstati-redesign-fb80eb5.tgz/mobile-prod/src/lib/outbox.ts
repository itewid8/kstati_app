/**
 * Отправка очереди правок пачками (POST /ops). Чистый модуль: запрос, очередь и разбор ошибок передаются снаружи.
 *
 * Ошибка запроса:
 *   auth   — токен не действует: пробрасываем (выход из аккаунта);
 *   retry  — нет связи, 5xx, 408, 429: пробрасываем, пачка остаётся в очереди до следующей попытки;
 *   reject — сервер отверг пачку (400, 409, 422 и прочие 4xx): делим пополам, пока не найдём плохую операцию;
 *            её убираем из очереди (onReject — в журнал и карантин), остальное отправляется.
 * Раньше любая 4xx оставляла пачку в очереди навсегда, и синхронизация вставала: pull не шёл, пока очередь не пуста.
 */

export type FailKind = 'auth' | 'retry' | 'reject';

export type OutboxDeps<O> = {
  /** Текущая очередь */
  read: () => readonly O[];
  /** Отправить пачку; ошибка — исключение */
  send: (batch: O[]) => Promise<void>;
  /** Убрать из очереди отправленное (по ссылке: пока шёл запрос, в конец могли добавиться новые операции) */
  remove: (done: readonly O[]) => void;
  classify: (e: unknown) => FailKind;
  /** Операция, которую сервер не принимает: в журнал, из очереди её уберёт remove */
  onReject: (op: O, e: unknown) => void;
  batchSize?: number;
};

async function sendSplit<O>(batch: O[], d: OutboxDeps<O>): Promise<void> {
  try {
    await d.send(batch);
  } catch (e) {
    if (d.classify(e) !== 'reject') throw e;
    if (batch.length === 1) {
      d.onReject(batch[0] as O, e);
      d.remove(batch);
      return;
    }
    const mid = Math.ceil(batch.length / 2);
    await sendSplit(batch.slice(0, mid), d);
    await sendSplit(batch.slice(mid), d);
    return;
  }
  d.remove(batch);
}

/** Отправить всю очередь. Пробрасывает только auth и retry */
export async function flushOutbox<O>(d: OutboxDeps<O>): Promise<void> {
  const size = d.batchSize ?? 100;
  for (;;) {
    const outbox = d.read();
    if (!outbox.length) return;
    await sendSplit(outbox.slice(0, size), d);
    // Защита от бесконечного цикла: отправленное должно было уйти из очереди
    if (d.read()[0] === outbox[0]) return;
  }
}
