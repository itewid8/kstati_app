/**
 * Синхронизация с сервером. Телефон — главный для своих правок, сервер — для общего.
 *
 * 1. Любая правка дел, «Смотреть» и своих хотелок в хранилище сама превращается в операцию
 *    (сравниваем списки до и после) и встаёт в очередь outbox. Группы и профиль ставят операции явно.
 * 2. Очередь отправляется пачкой на POST /ops; нет связи — лежит и ждёт (очередь сохраняется на телефоне).
 * 3. Когда очередь пуста — POST /sync: сервер присылает группы и людей, а записи — только там,
 *    где ревизия поменялась. Группы, по которым есть неотправленные правки, не перезаписываем.
 *    Разбор ответа и слияние — remote.ts (чистый модуль, с тестами); неизменённые данные сохраняют ссылки.
 * 4. Операции, которые сервер отверг целиком (4xx), не держат очередь: плохая находится делением пачки
 *    и уходит в карантин (outbox.ts). В очереди ждут только ошибки связи и 5xx.
 * Когда: при запуске, при возвращении в приложение, раз в 15 секунд, пока оно открыто, и сразу после правки.
 */
import { AppState } from 'react-native';
import { fetchHealth } from './api';
import { API_LEVEL, ApiError, NetError, request, type Op, type OpResult } from './net';
import { flushOutbox, type FailKind } from './outbox';
import { isEmptyPatch, mergePull, parseSync } from './remote';
import { flushStorage } from './storage';
import { applyRemote, DEMO, isApplyingRemote, syncHooks, useStore } from './store';
import type { Activity, ID, Idea, ReminderSettings, Task, TaskReminderOverride, Topic, WatchItem, Wish } from './types';

/** Изменения личных напоминаний → операция prefs (только то, что поменялось) */
function prefsOp(
  before: { reminders: ReminderSettings; overrides: Record<ID, TaskReminderOverride> },
  after: { reminders: ReminderSettings; overrides: Record<ID, TaskReminderOverride> },
): Op | null {
  const op: Extract<Op, { op: 'prefs' }> = { op: 'prefs' };
  if (before.reminders !== after.reminders) op.reminders = after.reminders;
  if (before.overrides !== after.overrides) {
    const changed: Record<string, string[] | null> = {};
    for (const [id, v] of Object.entries(after.overrides)) if (before.overrides[id] !== v) changed[id] = v;
    for (const id of Object.keys(before.overrides)) if (!(id in after.overrides)) changed[id] = null;
    if (Object.keys(changed).length) op.overrides = changed;
  }
  return op.reminders || op.overrides ? op : null;
}

/* ---------- правки в хранилище → операции ---------- */

const taskOp = (t: Task): Op => ({
  op: 'task.put',
  task: {
    id: t.id,
    groupId: t.groupId,
    title: t.title,
    date: t.date,
    time: t.time,
    note: t.note ?? '',
    doneAt: t.doneAt,
    repeat: t.repeat ?? null,
    doneDates: t.doneDates ?? [],
    skipDates: t.skipDates ?? [],
    reminders: t.reminders ?? null,
    endDate: t.endDate ?? null,
    endTime: t.endTime ?? null,
    people: t.people ?? [],
    parentId: t.parentId ?? null,
  },
});
const watchOp = (w: WatchItem): Op => ({
  op: 'watch.put',
  watch: { id: w.id, groupId: w.groupId, title: w.title, kind: w.kind, genres: w.genres, origin: w.origin, year: w.year, watchedAt: w.watchedAt },
});
const wishOp = (w: Wish): Op => ({ op: 'wish.put', wish: { id: w.id, title: w.title, note: w.note, link: w.link, receivedAt: w.receivedAt } });
// archivedAt уходит, только если его трогали: старый сервер без поля и чужие правки его не стирают
const topicOp = (t: Topic): Op => ({
  op: 'topic.put',
  topic: { id: t.id, title: t.title, groupIds: t.groupIds, ...(t.archivedAt !== undefined && { archivedAt: t.archivedAt }) },
});
const ideaOp = (i: Idea): Op => ({ op: 'idea.put', idea: { id: i.id, topicId: i.topicId, text: i.text } });

function diff<T extends { id: string }>(before: T[], after: T[], put: (x: T) => Op, del: (x: T) => Op): Op[] {
  if (before === after) return [];
  const prev = new Map(before.map((x) => [x.id, x]));
  const ops: Op[] = [];
  for (const x of after) {
    // Объекты в хранилище не меняются на месте: другая ссылка — значит, запись изменили
    if (prev.get(x.id) !== x) ops.push(put(x));
    prev.delete(x.id);
  }
  for (const x of prev.values()) ops.push(del(x));
  return ops;
}

useStore.subscribe((s, p) => {
  if (isApplyingRemote() || DEMO || !s.session || s.session !== p.session) return;
  const meId = s.me?.id;
  const ops = [
    ...diff(p.tasks, s.tasks, taskOp, (t) => ({ op: 'item.delete', groupId: t.groupId, id: t.id })),
    ...diff(p.watch, s.watch, watchOp, (w) => ({ op: 'item.delete', groupId: w.groupId, id: w.id })),
    ...diff(
      p.wishes.filter((w) => w.ownerId === meId),
      s.wishes.filter((w) => w.ownerId === meId),
      wishOp,
      (w) => ({ op: 'wish.delete', id: w.id }),
    ),
    // Сначала темы: новая идея может ссылаться на только что созданную тему
    ...diff(
      p.topics.filter((t) => t.ownerId === meId),
      s.topics.filter((t) => t.ownerId === meId),
      topicOp,
      (t) => ({ op: 'topic.delete', id: t.id }),
    ),
    ...diff(
      p.ideas.filter((i) => i.ownerId === meId),
      s.ideas.filter((i) => i.ownerId === meId),
      ideaOp,
      (i) => ({ op: 'idea.delete', id: i.id }),
    ),
  ];
  const prefs = prefsOp(p, s);
  if (prefs) ops.push(prefs);
  // Записи групп, из которых ушли (выход, исключение) — удалять на сервере не нужно, это делает сервер
  const alive = new Set(s.groups.map((g) => g.id));
  const filtered = ops.filter((o) => o.op !== 'item.delete' || alive.has(o.groupId));
  if (filtered.length) s.queue(filtered);
});

/* ---------- отправка и получение ---------- */

let running: Promise<void> | null = null;
let again = false;
let failures = 0;
let retryTimer: ReturnType<typeof setTimeout> | null = null;

/** Ошибка запроса: выйти (401), повторить позже (нет связи, 5xx, 408, 429) или отвергнуто сервером (прочие 4xx) */
function failKind(e: unknown): FailKind {
  if (e instanceof ApiError) {
    if (e.status === 401) return 'auth';
    if (e.status >= 500 || e.status === 408 || e.status === 429) return 'retry';
    if (e.status >= 400) return 'reject';
  }
  return 'retry';
}

/** Сколько отвергнутых операций держим для разбора */
const QUARANTINE_MAX = 50;

function flush(token: string): Promise<void> {
  return flushOutbox<Op>({
    read: () => useStore.getState().outbox,
    send: async (batch) => {
      const res = await request<{ results?: OpResult[] } | null>('/ops', { token, body: { ops: batch } });
      (res?.results ?? []).forEach((r, i) => {
        if (!r.ok) console.warn('Операция отклонена сервером', batch[i]?.op, r.error, r.message);
      });
    },
    // Убираем отправленное (пока шёл запрос, в конец могли добавиться новые операции)
    remove: (done) => useStore.setState({ outbox: useStore.getState().outbox.filter((o) => !done.includes(o)) }),
    classify: failKind,
    onReject: (op, e) => {
      console.warn('Сервер не принял операцию — убрана из очереди', op.op, e instanceof ApiError ? `${e.status} ${e.code} ${e.message}` : e);
      useStore.setState({ quarantine: [...useStore.getState().quarantine, op].slice(-QUARANTINE_MAX) });
    },
  });
}

async function pull(token: string) {
  const s0 = useStore.getState();
  const raw = await request<unknown>('/sync', { token, body: { ...s0.revs, ideas: s0.ideaRevs } });
  const s = useStore.getState();
  if (s.session?.token !== token) return; // пока ждали — вышли из аккаунта
  const { patch, uploadPrefs } = mergePull(s, parseSync(raw));
  // Ничего не поменялось — не трогаем хранилище: ни перерисовок, ни записи на диск
  if (!isEmptyPatch(patch)) applyRemote(() => useStore.setState(patch));
  if (uploadPrefs) {
    const cur = useStore.getState();
    cur.queue([{ op: 'prefs', reminders: cur.reminders, overrides: Object.fromEntries(Object.entries(cur.overrides)) }]);
  }
}

/** Отправить очередь и забрать новое. Повторные вызовы во время работы склеиваются и ждут общего окончания */
export function syncNow(): Promise<void> {
  if (DEMO) return Promise.resolve();
  if (running) {
    again = true;
    return running;
  }
  running = (async () => {
    try {
      do {
        again = false;
        await syncOnce();
      } while (again);
    } finally {
      running = null;
    }
  })();
  return running;
}

async function syncOnce(): Promise<void> {
  const token = useStore.getState().session?.token;
  if (!token) return;
  try {
    await flush(token);
    await pull(token);
    failures = 0;
    useStore.getState().setNet('ok');
    await fetchActivity();
  } catch (e) {
    const kind = failKind(e);
    if (kind === 'auth') {
      // Токен больше не действует — выходим, экраны по authLost переводят на вход
      useStore.getState().authExpired();
    } else if (e instanceof NetError || (e instanceof ApiError && kind === 'retry')) {
      failures++;
      useStore.getState().setNet('offline');
      // Повтор с растущей паузой: 5 с, 10 с … до минуты
      if (retryTimer) clearTimeout(retryTimer);
      retryTimer = setTimeout(syncNow, Math.min(60_000, 5_000 * 2 ** Math.min(failures - 1, 4)));
    } else {
      console.warn('Синхронизация', e);
    }
  }
}

/* ---------- лента активности ---------- */

let activityAt = 0;

/**
 * Забрать новые записи ленты (только те, что свежее последней известной).
 * Не чаще раза в минуту; force — сразу (открыли ленту, потянули вниз). Ошибки ленты молча пропускаем.
 */
export async function fetchActivity(force = false): Promise<void> {
  const s = useStore.getState();
  const token = s.session?.token;
  if (DEMO || !token) return;
  if (!force && Date.now() - activityAt < 60_000) return;
  activityAt = Date.now();
  try {
    const since = s.activity[0]?.id;
    const r = await request<{ events: Activity[] }>(`/activity${since ? `?since=${encodeURIComponent(since)}` : ''}`, { token });
    if (useStore.getState().session?.token === token) useStore.getState().mergeActivity(r.events);
  } catch {
    /* нет связи или лента ещё не готова на сервере */
  }
}

/* ---------- уровень API сервера ---------- */

let serverChecked = false;

/**
 * GET /health → serverApi. Сервер ниже API 2 молча срежет подарки и архив тем — тогда один раз говорим об этом,
 * а экраны не показывают эти действия. Нет связи — проверим при следующем возвращении в приложение
 */
async function checkServer(): Promise<void> {
  if (serverChecked) return;
  const h = await fetchHealth();
  if (!h) return;
  serverChecked = true;
  const s = useStore.getState();
  s.setServerApi(h.api);
  if (h.api < API_LEVEL) s.notice('Сервер устарел');
}

/** Запуск: из корневого экрана. Возвращает функцию остановки */
export function startSync(): () => void {
  if (DEMO) return () => {};
  let kickTimer: ReturnType<typeof setTimeout> | null = null;
  syncHooks.kick = () => {
    if (kickTimer) clearTimeout(kickTimer);
    kickTimer = setTimeout(syncNow, 400);
  };
  let interval: ReturnType<typeof setInterval> | null = null;
  const onActive = () => {
    void checkServer();
    syncNow();
    if (!interval) interval = setInterval(syncNow, 15_000);
  };
  const onBackground = () => {
    if (interval) clearInterval(interval);
    interval = null;
  };
  const sub = AppState.addEventListener('change', (st) => {
    if (st === 'active') return onActive();
    onBackground();
    // iOS может остановить приложение сразу после ухода в фон: отложенная запись на диск не успела бы
    if (st === 'background' || st === 'inactive') flushStorage();
  });
  onActive();
  return () => {
    sub.remove();
    onBackground();
    if (kickTimer) clearTimeout(kickTimer);
    kickTimer = null;
    if (retryTimer) clearTimeout(retryTimer);
    retryTimer = null;
    syncHooks.kick = () => {};
  };
}
