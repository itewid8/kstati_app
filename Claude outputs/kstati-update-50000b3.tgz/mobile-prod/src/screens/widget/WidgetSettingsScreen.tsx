/**
 * Настройки виджета на рабочем столе: кнопка REC и её цвет, фон и прозрачность, цвет названий и времени, группа.
 * Открывается из настроек приложения (общие для всех виджетов) и из «Настроить» на самом виджете (Android, свои у виджета).
 * Презентационный экран: данные — пропсами, действия — колбэками. Снизу ОТМЕНА / СОХРАНИТЬ.
 */
import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { WidgetPrefs, WidgetTone } from '@/lib/widgetData';
import { SectionBox, size as S, useTheme } from '@/ui';
import { AccountPage, type PageInsets } from '../account/components/AccountPage';
import { OptionGrid, type Option } from '../account/components/OptionGrid';
import { Toggle } from '../account/components/Toggle';
import { accountText } from '../account/components/accountTheme';

export type WidgetGroupOption = { id: string; name: string };

export type WidgetSettingsScreenProps = {
  prefs: WidgetPrefs;
  groups: readonly WidgetGroupOption[];
  canSave: boolean;
  insets: PageInsets;
  onChange?: (prefs: WidgetPrefs) => void;
  onCancel?: () => void;
  onSave?: () => void;
};

const TONES: ReadonlyArray<Option<WidgetTone>> = [
  { key: 'auto', label: 'КАК В ТЕМЕ' },
  { key: 'light', label: 'СВЕТЛЫЙ' },
  { key: 'dark', label: 'ТЁМНЫЙ' },
];

type Transparency = '0' | '25' | '50' | '75';
const TRANSPARENCY: ReadonlyArray<Option<Transparency>> = [
  { key: '0', label: '0%' },
  { key: '25', label: '25%' },
  { key: '50', label: '50%' },
  { key: '75', label: '75%' },
];
const ALL = 'all';

const nearestTransparency = (opacity: number): Transparency => {
  const pct = Math.round((1 - opacity) * 100);
  const best = TRANSPARENCY.reduce((a, b) => (Math.abs(Number(b.key) - pct) < Math.abs(Number(a.key) - pct) ? b : a));
  return best.key;
};

export const WidgetSettingsScreen = memo(function WidgetSettingsScreen(props: WidgetSettingsScreenProps) {
  const { prefs, groups, canSave, insets, onChange, onCancel, onSave } = props;
  const { c } = useTheme();
  const set = (patch: Partial<WidgetPrefs>) => onChange?.({ ...prefs, ...patch });
  const groupOptions: ReadonlyArray<Option<string>> = [{ key: ALL, label: 'ВСЕ' }, ...groups.map((g) => ({ key: g.id, label: g.name.toUpperCase() }))];

  return (
    <AccountPage caption="НАСТРОЙКИ" title="Виджет" insets={insets} onBack={onCancel} save={{ canSave, onCancel, onSave }}>
      <SectionBox title="КНОПКА REC">
        <View style={[styles.switchRow, { backgroundColor: c.panel }]}>
          <Text style={[accountText.rowLabel, { color: c.text }]}>Показывать</Text>
          <Toggle value={prefs.mic} onChange={(mic) => set({ mic })} accessibilityLabel="Кнопка REC" />
        </View>
        {prefs.mic ? <OptionGrid options={TONES} value={prefs.micTone} onChange={(micTone) => set({ micTone })} /> : null}
      </SectionBox>
      <SectionBox title="ФОН">
        <OptionGrid options={TONES} value={prefs.bg} onChange={(bg) => set({ bg })} />
      </SectionBox>
      <SectionBox title="ПРОЗРАЧНОСТЬ ФОНА">
        <OptionGrid
          options={TRANSPARENCY}
          value={nearestTransparency(prefs.opacity)}
          onChange={(t) => set({ opacity: 1 - Number(t) / 100 })}
        />
      </SectionBox>
      <SectionBox title="НАЗВАНИЯ">
        <OptionGrid options={TONES} value={prefs.text} onChange={(text) => set({ text })} />
      </SectionBox>
      <SectionBox title="ВРЕМЯ">
        <OptionGrid options={TONES} value={prefs.time} onChange={(time) => set({ time })} />
      </SectionBox>
      {groups.length > 1 ? (
        <SectionBox title="ГРУППА">
          <OptionGrid options={groupOptions} value={prefs.group ?? ALL} onChange={(g) => set({ group: g === ALL ? null : g })} />
        </SectionBox>
      ) : null}
    </AccountPage>
  );
});

const styles = StyleSheet.create({
  switchRow: {
    height: S.row,
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
