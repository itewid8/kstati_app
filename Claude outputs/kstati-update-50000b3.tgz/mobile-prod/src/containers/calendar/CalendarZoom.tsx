/**
 * Щипок между видами календаря: день ↔ неделя ↔ месяц ↔ год.
 * Пока пальцы на экране, текущий вид масштабируется вокруг точки щипка и растворяется (поток UI, без JS на кадр).
 * Отпустили дальше порога — вид переключается, новый проступает из своего масштаба пружиной; иначе пружиной назад.
 * Математика — src/lib/calendarLayout/zoom.ts, какой период откроется — src/adapters/calendar/zoom.ts.
 */
import * as Haptics from 'expo-haptics';
import { useCallback, useEffect, type ReactNode } from 'react';
import { StyleSheet, useWindowDimensions } from 'react-native';
import { Gesture, GestureDetector } from 'react-native-gesture-handler';
import Animated, {
  runOnJS,
  useAnimatedStyle,
  useReducedMotion,
  useSharedValue,
  withSpring,
  withTiming,
} from 'react-native-reanimated';
import { zoomTarget } from '@/adapters/calendar/zoom';
import {
  zoomCommits,
  zoomDir,
  zoomEnterScale,
  zoomExitScale,
  zoomFollow,
  zoomNext,
  zoomProgress,
  zoomShift,
  type ZoomDir,
  type ZoomView,
} from '@/lib/calendarLayout';
import { useStore } from '@/lib/store';
import { toISODate } from '@/lib/dates';
import { size as S } from '@/ui';
import { useInsets } from '../common';

const SPRING = { damping: 22, stiffness: 220, mass: 0.9 } as const;

type Props = { view: ZoomView; children: ReactNode };

export function CalendarZoom({ view, children }: Props) {
  const { width, height } = useWindowDimensions();
  const insets = useInsets();
  const reduced = useReducedMotion();

  const scale = useSharedValue(1);
  const opacity = useSharedValue(1);
  const tx = useSharedValue(0);
  const ty = useSharedValue(0);
  const dir = useSharedValue<ZoomDir>(0);
  const focal = useSharedValue({ x: width / 2, y: height / 2 });

  // Новый вид после переключения проступает из своего масштаба (крупнее период — из большего)
  const enterFrom = useSharedValue<ZoomDir>(0);
  useEffect(() => {
    const d = enterFrom.value;
    if (d === 0) return;
    enterFrom.value = 0;
    if (reduced) {
      scale.value = 1;
      opacity.value = 1;
      return;
    }
    scale.value = zoomEnterScale(0, d);
    opacity.value = 0;
    tx.value = 0;
    ty.value = 0;
    scale.value = withSpring(1, SPRING);
    opacity.value = withTiming(1, { duration: 220 });
  }, [view, reduced, enterFrom, scale, opacity, tx, ty]);

  const commit = useCallback(
    (d: ZoomDir, x: number, y: number) => {
      const s = useStore.getState();
      const target = zoomTarget({
        view,
        date: s.calendarDate,
        dir: d,
        x,
        y,
        frame: { width, height, top: insets.top, bottom: insets.bottom + S.contentBottom },
        today: toISODate(new Date()),
      });
      if (!target) return;
      Haptics.selectionAsync().catch(() => {});
      enterFrom.value = d;
      s.setCalendarDate(target.date);
      s.setTasksView(target.view);
    },
    [view, width, height, insets, enterFrom],
  );

  const pinch = Gesture.Pinch()
    .onStart((e) => {
      focal.value = { x: e.focalX, y: e.focalY };
      dir.value = 0;
    })
    .onUpdate((e) => {
      const d = zoomDir(e.scale);
      if (d !== 0) dir.value = d;
      const can = zoomNext(view, dir.value) !== null;
      const s = zoomFollow(e.scale, can);
      const shift = zoomShift(s, focal.value.x, focal.value.y, width, height);
      scale.value = s;
      tx.value = shift.x;
      ty.value = shift.y;
      opacity.value = can ? 1 - 0.85 * zoomProgress(e.scale, dir.value) : 1;
    })
    .onEnd((e) => {
      const d = dir.value;
      if (zoomNext(view, d) !== null && zoomCommits(e.scale, e.velocity, d)) {
        const s = zoomExitScale(d);
        const shift = zoomShift(s, focal.value.x, focal.value.y, width, height);
        scale.value = withTiming(s, { duration: 140 });
        tx.value = withTiming(shift.x, { duration: 140 });
        ty.value = withTiming(shift.y, { duration: 140 });
        opacity.value = withTiming(0, { duration: 140 }, (done) => {
          if (done) runOnJS(commit)(d, focal.value.x, focal.value.y);
        });
        return;
      }
      scale.value = withSpring(1, SPRING);
      tx.value = withSpring(0, SPRING);
      ty.value = withSpring(0, SPRING);
      opacity.value = withTiming(1, { duration: 160 });
    });

  const style = useAnimatedStyle(() => ({
    opacity: opacity.value,
    transform: [{ translateX: tx.value }, { translateY: ty.value }, { scale: scale.value }],
  }));

  return (
    <GestureDetector gesture={pinch}>
      <Animated.View style={[styles.fill, style]}>{children}</Animated.View>
    </GestureDetector>
  );
}

const styles = StyleSheet.create({ fill: { flex: 1 } });
