/**
 * Настройки виджета. Без widgetId — общие для всех виджетов (из настроек приложения): сохраняются в «default»,
 * свои настройки виджетов сбрасываются. С widgetId — окно «Настроить» одного виджета на Android.
 */
import { router } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import { myGroups, prefsFor, withSharedPrefs, withWidgetPrefs, type WidgetPrefs } from '@/lib/widgetData';
import { WidgetSettingsScreen } from '@/screens/widget/WidgetSettingsScreen';
import { finishWidgetConfig, reloadWidget, reloadWidgets } from '../../../modules/kstati-widget';
import { readPrefsFile, writePrefsFile } from '../../widget/files';
import { updateWidget } from '../../widget/sync';
import { useInsets } from '../common';

type Props = { widgetId?: number };

const samePrefs = (a: WidgetPrefs, b: WidgetPrefs) => (Object.keys(a) as (keyof WidgetPrefs)[]).every((k) => a[k] === b[k]);

export function WidgetSettingsContainer({ widgetId }: Props) {
  const insets = useInsets();
  const me = useStore((s) => s.me);
  const allGroups = useStore((s) => s.groups);
  const groups = useMemo(() => (me ? myGroups({ me, groups: allGroups }) : []), [me, allGroups]);
  const initial = useMemo(() => prefsFor(readPrefsFile(), widgetId ?? null), [widgetId]);
  const [prefs, setPrefs] = useState(initial);

  const close = useCallback(
    (saved: boolean) => {
      if (widgetId !== undefined) finishWidgetConfig(saved);
      else if (router.canGoBack()) router.back();
    },
    [widgetId],
  );

  const onSave = useCallback(() => {
    try {
      writePrefsFile(widgetId !== undefined ? withWidgetPrefs(readPrefsFile(), widgetId, prefs) : withSharedPrefs(prefs));
      updateWidget();
      if (widgetId !== undefined) reloadWidget(widgetId);
      else reloadWidgets();
    } catch (e) {
      console.warn('Настройки виджета не сохранены', e);
    }
    close(true);
  }, [prefs, widgetId, close]);

  return (
    <WidgetSettingsScreen
      prefs={prefs}
      groups={groups}
      canSave={!samePrefs(prefs, initial)}
      insets={insets}
      onChange={setPrefs}
      onCancel={() => close(false)}
      onSave={onSave}
    />
  );
}
