/**
 * Заметка (C-Note, src/screens/lists/NoteScreen). Своя — правится по строкам (lib/noteEdit.ts), сохраняется сама
 * через полсекунды после правки и при выходе; очистили и вышли — заметка удаляется. Новая (id NEW_NOTE) появляется
 * в теме topicId с первым словом. Чужая — только читать. «⋯» — быстрые действия (в дела, копия, в тему, удалить).
 */
import { router } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { Keyboard } from 'react-native';
import { upper } from '@/adapters/common/ru';
import { uid } from '@/lib/ids';
import { isBlankNote, parseNote, serializeNote, type NoteBlock } from '@/lib/note';
import { applyTool, backspaceEmpty, changeText, startBlocks, toggleCheck, type NoteCaret, type NoteTool } from '@/lib/noteEdit';
import { useStore } from '@/lib/store';
import type { ID } from '@/lib/types';
import { NoteScreen } from '@/screens/lists/NoteScreen';
import { NEW_NOTE, nav, signedInOnly, useInsets } from '../common';
import { holdIdea } from '../quick/quickStore';

const SAVE_MS = 500;

const back = (topicId: ID | null) => (router.canGoBack() ? router.back() : router.navigate(topicId ? nav.topic(topicId) : nav.tab('ideas')));

export const NoteContainer = signedInOnly(function Note({ id: routeId, topicId: routeTopic }: { id: ID; topicId: ID | null }) {
  // Новая заметка получает id сразу: с первым словом она уже в теме
  const [id] = useState(() => (routeId === NEW_NOTE ? uid() : routeId));
  const idea = useStore((s) => s.ideas.find((x) => x.id === id));
  const meId = useStore((s) => s.me?.id);
  const topicId = idea ? idea.topicId : routeTopic;
  const topicTitle = useStore((s) => (topicId ? s.topics.find((t) => t.id === topicId)?.title : undefined));
  const insets = useInsets();
  const editable = !idea || idea.ownerId === meId;

  const [blocks, setBlocks] = useState<NoteBlock[]>(() => startBlocks(idea ? parseNote(idea.text) : []));
  const [active, setActive] = useState<number | null>(null);
  const [caret, setCaret] = useState<(NoteCaret & { nonce: number }) | null>(() => (idea ? null : { index: 0, at: 0, nonce: 1 }));
  const latest = useRef(blocks);
  latest.current = blocks;
  const existed = useRef(!!idea);
  if (idea) existed.current = true;

  const moveCaret = useCallback((c: NoteCaret | null) => {
    if (!c) return;
    setActive(c.index);
    setCaret((p) => ({ ...c, nonce: (p?.nonce ?? 0) + 1 }));
  }, []);

  /** Записать в хранилище (оттуда — на сервер): пустая новая не создаётся */
  const save = useCallback(() => {
    if (!editable) return;
    const b = latest.current;
    if (isBlankNote(b)) return;
    useStore.getState().putNote(id, topicId, serializeNote(b));
  }, [editable, id, topicId]);

  // Сохранение через полсекунды после правки
  const first = useRef(true);
  useEffect(() => {
    if (first.current) {
      first.current = false;
      return;
    }
    const t = setTimeout(save, SAVE_MS);
    return () => clearTimeout(t);
  }, [blocks, save]);

  // Выход: сохранить; очистили свою — удалить
  useEffect(
    () => () => {
      if (!editable) return;
      if (isBlankNote(latest.current)) {
        if (useStore.getState().ideas.some((x) => x.id === id)) useStore.getState().dropIdea(id);
        return;
      }
      save();
    },
    [editable, id, save],
  );

  // Заметку удалили (быстрые действия, другой телефон) — уходим
  useEffect(() => {
    if (existed.current && !idea) back(topicId);
  }, [idea, topicId]);

  const onChangeText = useCallback(
    (i: number, text: string) => {
      const r = changeText(latest.current, i, text);
      setBlocks(r.blocks);
      moveCaret(r.caret);
    },
    [moveCaret],
  );
  const onBackspace = useCallback(
    (i: number) => {
      const r = backspaceEmpty(latest.current, i);
      if (r.blocks.length === latest.current.length && r.blocks.every((b, j) => b === latest.current[j])) return;
      setBlocks(r.blocks);
      moveCaret(r.caret);
    },
    [moveCaret],
  );
  const onToggleCheck = useCallback((i: number) => setBlocks(toggleCheck(latest.current, i)), []);
  const onTool = useCallback(
    (tool: NoteTool) => {
      if (active === null) return;
      setBlocks(applyTool(latest.current, active, tool));
    },
    [active],
  );
  const onDone = useCallback(() => {
    Keyboard.dismiss();
    back(topicId);
  }, [topicId]);
  const onMore = useCallback(() => {
    Keyboard.dismiss();
    save();
    if (useStore.getState().ideas.some((x) => x.id === id)) holdIdea(id);
  }, [id, save]);

  const caption = useMemo(() => `ЗАМЕТКА · ${upper(topicTitle ?? 'Без темы')}`, [topicTitle]);

  return (
    <NoteScreen
      caption={caption}
      blocks={blocks}
      editable={editable}
      active={active}
      caret={caret}
      insets={insets}
      onBack={onDone}
      onMore={idea ? onMore : undefined}
      onChangeText={onChangeText}
      onBackspace={onBackspace}
      onToggleCheck={onToggleCheck}
      onFocus={setActive}
      onTool={onTool}
      onDone={onDone}
    />
  );
});
