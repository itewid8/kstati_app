/**
 * Заметка (C-Note): назад + подпись темы, «⋯»; строки заметки по видам (lib/note.ts) — заголовок, текст,
 * жирная строка, чек-лист, нумерованный и маркированный список. Своя — правится прямо в строках, снизу (над клавиатурой)
 * панель: чек-лист, «1.», список, «H», «B» (вид строки с курсором подсвечен) и ГОТОВО. Чужая — только читать.
 * Презентационный экран: строки и курсор — пропсами, правки — колбэками (логика правки — lib/noteEdit.ts).
 */
import { memo, useEffect, useRef, useState } from 'react';
import {
  Keyboard,
  Platform,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  TextInput,
  View,
  type NativeSyntheticEvent,
  type TextInputKeyPressEventData,
} from 'react-native';
import type { NoteBlock } from '@/lib/note';
import { numberOf } from '@/lib/note';
import type { NoteCaret, NoteTool } from '@/lib/noteEdit';
import { Checkbox, Icon, TopBar, fonts, size as S, space, type as T, useTheme, type IconName, type TopBarAction } from '@/ui';
import { keyboardOverlap } from '../editors/components/revealMath';

export type NoteScreenProps = {
  /** «ЗАМЕТКА · ПОЕЗДКИ» */
  caption: string;
  blocks: readonly NoteBlock[];
  /** Своя заметка: строки правятся, есть панель */
  editable: boolean;
  /** Строка с курсором — её вид подсвечен на панели */
  active: number | null;
  /** Поставить курсор (меняется nonce — ставим снова) */
  caret?: (NoteCaret & { nonce: number }) | null;
  insets?: { top: number; bottom: number };
  onBack?: () => void;
  onMore?: () => void;
  onChangeText?: (index: number, text: string) => void;
  /** Backspace в пустой строке */
  onBackspace?: (index: number) => void;
  onToggleCheck?: (index: number) => void;
  onFocus?: (index: number) => void;
  onTool?: (tool: NoteTool) => void;
  onDone?: () => void;
};

const NO_INSETS = { top: 0, bottom: 0 };
const TOP = 72;
const TOOL = 44;
/** Панель: кнопки 44, сверху и снизу по 16; над клавиатурой — 8 */
const BAR_PAD = 16;
const KB_GAP = 8;
const WEB = Platform.OS === 'web';

const TOOLS: ReadonlyArray<{ key: NoteTool; label: string; icon?: IconName; glyph?: string }> = [
  { key: 'check', label: 'Чек-лист', icon: 'checklist' },
  { key: 'number', label: 'Нумерованный список', glyph: '1.' },
  { key: 'bullet', label: 'Список', icon: 'bullets' },
  { key: 'heading', label: 'Заголовок', glyph: 'H' },
  { key: 'bold', label: 'Жирный', glyph: 'B' },
];

/** Сколько снизу закрывает клавиатура (0 — её нет или окно уже сжато под неё) */
function useKeyboardOverlap(root: React.RefObject<View | null>): number {
  const [overlap, setOverlap] = useState(0);
  useEffect(() => {
    const ios = Platform.OS === 'ios';
    const show = Keyboard.addListener(ios ? 'keyboardWillShow' : 'keyboardDidShow', (e) => {
      const top = e.endCoordinates.screenY;
      root.current?.measureInWindow((_x, y, _w, h) => setOverlap(keyboardOverlap(y + h, top)));
    });
    const hide = Keyboard.addListener(ios ? 'keyboardWillHide' : 'keyboardDidHide', () => setOverlap(0));
    return () => {
      show.remove();
      hide.remove();
    };
  }, [root]);
  return overlap;
}

type LineProps = {
  b: NoteBlock;
  index: number;
  number: number;
  editable: boolean;
  setRef: (index: number, input: TextInput | null) => void;
} & Pick<NoteScreenProps, 'onChangeText' | 'onBackspace' | 'onToggleCheck' | 'onFocus'>;

const Line = memo(function Line({ b, index, number, editable, setRef, onChangeText, onBackspace, onToggleCheck, onFocus }: LineProps) {
  const { c } = useTheme();
  const heading = b.kind === 'heading';
  const done = b.kind === 'check' && !!b.checked;
  const style = [
    heading ? styles.heading : b.bold ? styles.bold : styles.text,
    { color: done ? c.muted : c.text },
    done && styles.done,
  ];
  // На web (стенд сверки) — текстом: поле ввода там не растёт по строкам
  const field =
    editable && !WEB ? (
      <TextInput
        ref={(r) => setRef(index, r)}
        value={b.text}
        multiline
        scrollEnabled={false}
        onChangeText={(t) => onChangeText?.(index, t)}
        onKeyPress={(e: NativeSyntheticEvent<TextInputKeyPressEventData>) => {
          if (e.nativeEvent.key === 'Backspace' && !b.text) onBackspace?.(index);
        }}
        onFocus={() => onFocus?.(index)}
        selectionColor={c.text}
        style={[style, styles.input, !heading && styles.flex]}
      />
    ) : (
      <Text style={[style, !heading && styles.flex]}>{b.text}</Text>
    );
  if (heading) return <View style={styles.line}>{field}</View>;
  return (
    <View style={[styles.line, styles.row]}>
      {b.kind === 'check' ? (
        <Checkbox
          checked={done}
          onPress={editable ? () => onToggleCheck?.(index) : undefined}
          accessibilityLabel={b.text || 'Пункт'}
          emptyFill="none"
          tapWidth={22}
          tapHeight={22}
        />
      ) : null}
      {b.kind === 'number' ? <Text style={[styles.number, { color: c.text }]}>{`${number}.`}</Text> : null}
      {b.kind === 'bullet' ? (
        <View style={styles.mark}>
          <View style={[styles.bullet, { backgroundColor: c.text }]} />
        </View>
      ) : null}
      {field}
    </View>
  );
});

export const NoteScreen = memo(function NoteScreen(props: NoteScreenProps) {
  const { caption, blocks, editable, active, caret, insets = NO_INSETS, onBack, onMore, onTool, onDone } = props;
  const { c } = useTheme();
  const root = useRef<View>(null);
  const inputs = useRef<(TextInput | null)[]>([]);
  const setRef = useRef((index: number, input: TextInput | null) => {
    inputs.current[index] = input;
  }).current;
  const overlap = useKeyboardOverlap(root);

  // Курсор туда, куда сказали (новая строка после Enter, конец предыдущей после Backspace)
  useEffect(() => {
    if (!caret) return;
    const input = inputs.current[caret.index];
    if (!input) return;
    input.focus();
    const at = caret.at === 'end' ? (blocks[caret.index]?.text.length ?? 0) : caret.at;
    // setSelection есть у поля на iOS и Android, но не во всех типах React Native
    const select = (input as unknown as { setSelection?: (start: number, end: number) => void }).setSelection;
    requestAnimationFrame(() => select?.call(input, at, at));
    // blocks не в зависимостях: курсор ставим только по новому nonce
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [caret?.nonce]);

  const actions: TopBarAction[] = onMore ? [{ key: 'more', icon: 'dots', accessibilityLabel: 'Ещё', onPress: onMore }] : [];
  const cur = active !== null ? blocks[active] : undefined;
  const barBottom = overlap > 0 ? overlap + KB_GAP : insets.bottom + BAR_PAD;
  const bottomSpace = editable ? barBottom + TOOL + BAR_PAD : insets.bottom + BAR_PAD;

  return (
    <View ref={root} style={[styles.screen, { backgroundColor: c.bg }]}>
      <TopBar lead={{ kind: 'back', label: caption, onBack }} actions={actions} style={[styles.side, { top: insets.top + S.topBarTop }]} />
      <ScrollView
        style={[styles.scroll, { top: insets.top + TOP, bottom: bottomSpace, backgroundColor: c.bg }]}
        contentContainerStyle={styles.content}
        keyboardShouldPersistTaps="handled"
        showsVerticalScrollIndicator={false}
      >
        {blocks.map((b, i) => (
          <Line
            key={i}
            b={b}
            index={i}
            number={b.kind === 'number' ? numberOf(blocks, i) : 0}
            editable={editable}
            setRef={setRef}
            onChangeText={props.onChangeText}
            onBackspace={props.onBackspace}
            onToggleCheck={props.onToggleCheck}
            onFocus={props.onFocus}
          />
        ))}
      </ScrollView>
      {editable ? (
        <>
          <View style={[styles.bar, { height: barBottom + TOOL + BAR_PAD + S.hairline, backgroundColor: c.bg, borderTopColor: c.hair }]} />
          <View style={[styles.side, styles.tools, { bottom: barBottom }]}>
            {TOOLS.map((t) => {
              const on = !!cur && (t.key === 'bold' ? !!cur.bold : cur.kind === t.key);
              const ink = on ? c.bg : c.text;
              return (
                <Pressable
                  key={t.key}
                  accessibilityRole="button"
                  accessibilityLabel={t.label}
                  accessibilityState={{ selected: on, disabled: !cur }}
                  onPress={cur ? () => onTool?.(t.key) : undefined}
                  style={[styles.tool, { borderColor: c.border, backgroundColor: on ? c.text : c.panel }]}
                >
                  {t.icon ? <Icon name={t.icon} size={18} color={ink} /> : null}
                  {t.glyph === '1.' ? <Text style={[styles.toolNum, { color: ink }]}>1.</Text> : null}
                  {t.glyph === 'H' || t.glyph === 'B' ? (
                    <Text style={[t.glyph === 'H' ? styles.toolH : styles.toolB, { color: ink }]}>{t.glyph}</Text>
                  ) : null}
                </Pressable>
              );
            })}
            <Pressable accessibilityRole="button" onPress={onDone} style={[styles.doneButton, { borderColor: c.border, backgroundColor: c.text }]}>
              <Text style={[T.action, { color: c.bg }]}>ГОТОВО</Text>
            </Pressable>
          </View>
        </>
      ) : null}
    </View>
  );
});

const styles = StyleSheet.create({
  screen: { flex: 1 },
  side: { position: 'absolute', left: space.side, right: space.side },
  scroll: { position: 'absolute', left: 0, right: 0 },
  content: { paddingHorizontal: space.side },
  flex: { flex: 1, minWidth: 0 },
  line: { paddingVertical: 3 },
  row: { flexDirection: 'row', alignItems: 'flex-start', gap: 8 },
  heading: { fontFamily: fonts.sans700, fontSize: 24, lineHeight: 30, letterSpacing: -0.96 },
  text: { fontFamily: fonts.sans400, fontSize: 15, lineHeight: 22 },
  bold: { fontFamily: fonts.sans600, fontSize: 15, lineHeight: 22 },
  done: { textDecorationLine: 'line-through' },
  input: { padding: 0, margin: 0, includeFontPadding: false, textAlignVertical: 'top' },
  number: { width: 22, textAlign: 'right', fontFamily: fonts.mono600, fontSize: 13, lineHeight: 22 },
  mark: { width: 22, height: 22, alignItems: 'center', justifyContent: 'center' },
  bullet: { width: 5, height: 5 },
  bar: { position: 'absolute', left: 0, right: 0, bottom: 0, borderTopWidth: S.hairline },
  tools: { height: TOOL, flexDirection: 'row', gap: 6 },
  tool: { width: TOOL, height: TOOL, borderWidth: S.border, alignItems: 'center', justifyContent: 'center' },
  toolNum: { fontFamily: fonts.mono600, fontSize: 13, letterSpacing: -0.26 },
  toolH: { fontFamily: fonts.sans700, fontSize: 17, lineHeight: 20 },
  toolB: { fontFamily: fonts.sans700, fontSize: 17, lineHeight: 20 },
  doneButton: { flex: 1, height: TOOL, borderWidth: S.border, alignItems: 'center', justifyContent: 'center' },
});
