/**
 * Строки списков появляются и исчезают плавно: удалённая гаснет, соседние съезжают на её место,
 * возвращённая («ВЕРНУТЬ») проявляется. Первый показ списка — без анимации (ListMotion с skipEntering).
 */
import { memo, type ReactNode } from 'react';
import type { StyleProp, ViewStyle } from 'react-native';
import Animated, { FadeIn, FadeOut, LayoutAnimationConfig, LinearTransition } from 'react-native-reanimated';

const LAYOUT = LinearTransition.duration(220);
const ENTER = FadeIn.duration(220);
const EXIT = FadeOut.duration(160);

export const RowMotion = memo(function RowMotion({ children, style }: { children: ReactNode; style?: StyleProp<ViewStyle> }) {
  return (
    <Animated.View layout={LAYOUT} entering={ENTER} exiting={EXIT} style={style}>
      {children}
    </Animated.View>
  );
});

/** Обёртка списка: при первом показе (и при смене группы — новый key) строки появляются сразу, без анимации */
export function ListMotion({ children }: { children: ReactNode }) {
  return (
    <LayoutAnimationConfig skipEntering skipExiting>
      {children}
    </LayoutAnimationConfig>
  );
}
