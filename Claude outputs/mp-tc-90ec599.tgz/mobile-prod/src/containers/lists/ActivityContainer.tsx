import { router } from 'expo-router';
import { useEffect, useMemo, useState } from 'react';
import { activityProps } from '@/adapters/lists/activity';
import { colorMap, wishOwnerOf } from '@/adapters/common/people';
import { useStore } from '@/lib/store';
import { fetchActivity } from '@/lib/sync';
import type { ID } from '@/lib/types';
import { ActivityScreen } from '@/screens/lists/ActivityScreen';
import { nav, useClock, useInsets, useSnapshot } from '../common';

const back = () => (router.canGoBack() ? router.back() : router.navigate(nav.tab('tasks')));

/**
 * Куда ведёт событие. Хотелки — вишлист ВЛАДЕЛЬЦА хотелки (с API 2 автор подарка — даритель, а не владелец);
 * дело — его окно (удалённое — день в календаре); «Смотреть» — вкладка группы; участники и название — группа
 */
function openEvent(id: ID) {
  const st = useStore.getState();
  const e = st.activity.find((x) => x.id === id);
  if (!e) return;
  if (e.kind.startsWith('wish.')) {
    const owner = wishOwnerOf(e, st.wishes);
    st.setWishPerson(owner === st.me?.id ? null : owner);
    return router.navigate(nav.tab('wishes'));
  }
  if (e.kind === 'topic.share' && e.itemId) return router.push(nav.topic(e.itemId));
  if (!e.groupId || !st.groups.some((g) => g.id === e.groupId)) return;
  st.selectGroup(e.groupId);
  if (e.kind.startsWith('watch.')) return router.navigate(nav.tab('watch'));
  if (e.kind.startsWith('task.')) {
    const task = e.kind !== 'task.delete' && e.itemId ? st.tasks.find((t) => t.id === e.itemId) : undefined;
    if (task) return router.push(nav.taskEditor({ id: task.id }));
    if (e.date) st.setCalendarDate(e.date);
    return router.navigate(nav.tab('tasks'));
  }
  router.push(nav.group(e.groupId));
}

/** C-Activity: лента всех групп; при открытии — свежие события с сервера, при уходе — всё просмотрено */
export function ActivityContainer() {
  const s = useSnapshot();
  const { today } = useClock();
  const insets = useInsets();
  // Что было непросмотренным при входе, подсвечено до выхода
  const [seenBefore] = useState(() => useStore.getState().activitySeen);
  const colors = useMemo(() => colorMap(s), [s.me, s.users, s.groups]);
  // Первая загрузка ленты на этом телефоне: старое новым не считается (mergeActivity) — берём отметку после неё
  const seen = seenBefore || s.activitySeen;
  const data = useMemo(() => activityProps(s, colors, { today }, seen), [s, colors, today, seen]);

  useEffect(() => {
    void fetchActivity(true);
    return () => useStore.getState().markActivitySeen();
  }, []);

  return <ActivityScreen {...data} insets={insets} onBack={back} onOpenEvent={openEvent} />;
}
