import { useCallback, useMemo } from 'react';
import { Linking } from 'react-native';
import { emptyDraft } from '@/components/CardSheet';
import { colorMap } from '@/adapters/common/people';
import { ALL_PEOPLE, WISH_SECTIONS, parseWishKey, safeLink, wishesProps } from '@/adapters/lists/wishes';
import { DEMO, useStore } from '@/lib/store';
import type { ID } from '@/lib/types';
import { WishesScreen, type WishRow, type WishSection } from '@/screens/WishesScreen';
import { useChrome, useInsets, useSnapshot } from '../common';

/** Подарки чужих хотелок — только с сервером API 2 (старый молча срежет giftedBy) */
const giftsOn = (api: number | null) => DEMO || (api ?? 0) >= 2;

/**
 * Отметка в строке. Своя: «получил» (receivedAt). Чужая: «подарю» — сразу на сервер (отказ надо показать);
 * снять чужой подарок может только подаривший, остальное — без действия
 */
function toggleGift(key: string, gifted: boolean) {
  const ref = parseWishKey(key);
  const st = useStore.getState();
  const meId = st.me?.id;
  if (!ref || !meId) return;
  if (ref.ownerId === meId) return st.setReceived(ref.id, gifted);
  if (!giftsOn(st.serverApi)) return;
  const w = st.wishes.find((x) => x.ownerId === ref.ownerId && x.id === ref.id);
  if (!w || w.receivedAt) return;
  if (gifted ? !!w.giftedBy : w.giftedBy !== meId) return;
  void st.giftWish(ref.ownerId, ref.id, gifted).then((err) => {
    if (err) useStore.getState().notice(err);
  });
}

/** Ссылка чужой хотелки может быть любой строкой — открываем только http(s) */
function openLink(wish: WishRow) {
  const url = safeLink(wish.link);
  if (url) Linking.openURL(url).catch(() => {});
}

/** Своя хотелка — старая карточка правки; чужую не меняем */
function openWish(key: string) {
  const ref = parseWishKey(key);
  const st = useStore.getState();
  if (!ref || ref.ownerId !== st.me?.id) return;
  const w = st.wishes.find((x) => x.ownerId === ref.ownerId && x.id === ref.id);
  if (!w) return;
  st.setCard({ source: 'edit', editing: true, items: [{ key: w.id, id: w.id, type: 'wish', data: { title: w.title, note: w.note, link: w.link } }] });
}

const toggleSection = (section: WishSection) => useStore.getState().toggleSection(WISH_SECTIONS[section]);

/** C-Wishes: вишлисты — я и люди всех моих групп */
export function WishesContainer() {
  const s = useSnapshot();
  const insets = useInsets();
  const { onOpenFeed, onOpenSettings, onNavigate, onRec } = useChrome('wishes');
  const personId = useStore((st) => st.wishPersonId);
  const collapsed = useStore((st) => st.collapsedSections);
  const gifts = useStore((st) => giftsOn(st.serverApi));
  const colors = useMemo(() => colorMap(s), [s.me, s.users, s.groups]);
  const data = useMemo(() => wishesProps(s, colors, { personId, collapsed }), [s, colors, personId, collapsed]);
  const meId = s.me.id;
  const selected = data.selectedPersonId;
  // Вкладка другого человека: без API 2 отмечать нечего, открывать его хотелки нельзя
  const other = selected !== meId && selected !== ALL_PEOPLE;

  const onSelectPerson = useCallback((id: ID) => useStore.getState().setWishPerson(id === meId ? null : id), [meId]);
  const onAdd = useCallback(() => {
    const st = useStore.getState();
    if (other) st.setWishPerson(null);
    st.setCard({ source: 'manual', items: [emptyDraft('wish')], editing: true });
  }, [other]);

  return (
    <WishesScreen
      {...data}
      insets={insets}
      onSelectPerson={onSelectPerson}
      onToggleGift={other && !gifts ? undefined : toggleGift}
      onOpenLink={openLink}
      onOpenWish={other ? undefined : openWish}
      onToggleSection={toggleSection}
      onAdd={onAdd}
      onOpenFeed={onOpenFeed}
      onOpenSettings={onOpenSettings}
      onNavigate={onNavigate}
      onRec={onRec}
    />
  );
}
