import { Redirect, router } from 'expo-router';
import { useMemo } from 'react';
import { tasksListProps } from '@/adapters/lists/tasksList';
import { colorMap } from '@/adapters/common/people';
import { parseKey } from '@/adapters/common/tasks';
import { useStore } from '@/lib/store';
import type { ID } from '@/lib/types';
import { TasksListScreen, type TasksView } from '@/screens/lists/TasksListScreen';
import { nav, useChrome, useClock, useInsets, useSnapshot } from '../common';

const changeView = (v: TasksView) => {
  if (v !== 'list') useStore.getState().setTasksView(v);
};

/** Отметка по ключу строки: «id@дата» — раз серии */
const toggleTask = (key: ID) => {
  const { id, occ } = parseKey(key);
  useStore.getState().toggleTask(id, occ);
};

const openTask = (key: ID) => router.push(nav.taskEditor(parseKey(key)));
const openPlan = (id: ID) => router.push(nav.planGrid(id));
const addTask = () => router.push(nav.taskEditor({}));

/** C-List: вкладка «Дела» списком (s.tasksView === 'list'); нет группы — на онбординг */
export function TasksListContainer() {
  const s = useSnapshot();
  // Список меняется раз в день, а не каждую минуту
  const { today } = useClock();
  const insets = useInsets();
  const { onPickGroup, onOpenFeed, onOpenSettings, onNavigate, onRec } = useChrome('tasks');
  const colors = useMemo(() => colorMap(s), [s.me, s.users, s.groups]);
  const data = useMemo(() => tasksListProps(s, colors, { today }), [s, colors, today]);

  if (!s.groups.length) return <Redirect href="/onboarding" />;

  return (
    <TasksListScreen
      {...data}
      insets={insets}
      onPickGroup={onPickGroup}
      onChangeView={changeView}
      onToggleTask={toggleTask}
      onOpenTask={openTask}
      onOpenPlan={openPlan}
      onAdd={addTask}
      onOpenFeed={onOpenFeed}
      onOpenSettings={onOpenSettings}
      onNavigate={onNavigate}
      onRec={onRec}
    />
  );
}
