import { router } from 'expo-router';
import { useMemo, useState } from 'react';
import { emptyDraft } from '@/components/CardSheet';
import { colorMap } from '@/adapters/common/people';
import { ALL_IDEAS, IDEAS_SECTIONS, ideasProps } from '@/adapters/lists/ideas';
import { DEMO, useStore } from '@/lib/store';
import type { ID } from '@/lib/types';
import { IdeasScreen, type IdeasSection } from '@/screens/lists/IdeasScreen';
import { nav, useChrome, useClock, useInsets, useSnapshot } from '../common';

/** Архив тем — только с сервером API 2 (старый молча срежет archivedAt) */
const archiveOn = (api: number | null) => DEMO || (api ?? 0) >= 2;

/** В архив и обратно — только свои темы; чужие и «Без темы» — без действия */
function toggleArchive(id: ID, archived: boolean) {
  const st = useStore.getState();
  const topic = st.topics.find((t) => t.id === id);
  if (topic && topic.ownerId === st.me?.id) st.archiveTopic(id, archived);
}

const openTopic = (id: ID) => router.push(nav.topic(id));
const addTopic = () => useStore.getState().setCard({ source: 'manual', items: [emptyDraft('topic')], editing: true });
const toggleSection = (section: IdeasSection) => useStore.getState().toggleSection(IDEAS_SECTIONS[section]);

/** C-Ideas: блокнот тем; вкладка человека — состояние экрана */
export function IdeasContainer() {
  const s = useSnapshot();
  const { today } = useClock();
  const insets = useInsets();
  const { onOpenFeed, onOpenSettings, onNavigate, onRec } = useChrome('ideas');
  const collapsed = useStore((st) => st.collapsedSections);
  const archive = useStore((st) => archiveOn(st.serverApi));
  const [personId, setPersonId] = useState<ID>(ALL_IDEAS);
  const colors = useMemo(() => colorMap(s), [s.me, s.users, s.groups]);
  const data = useMemo(() => ideasProps(s, colors, { today }, { personId, collapsed }), [s, colors, today, personId, collapsed]);

  return (
    <IdeasScreen
      {...data}
      insets={insets}
      onSelectPerson={setPersonId}
      onToggleArchive={archive ? toggleArchive : undefined}
      onOpenTopic={openTopic}
      onToggleSection={toggleSection}
      onAddTopic={addTopic}
      onOpenFeed={onOpenFeed}
      onOpenSettings={onOpenSettings}
      onNavigate={onNavigate}
      onRec={onRec}
    />
  );
}
