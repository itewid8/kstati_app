/**
 * Окно дела (C-EditDate / -Repeat / -Remind / -Who). Правки — в черновике (useEditorState), в хранилище — по «СОХРАНИТЬ»;
 * «назад» ничего не меняет. Новое дело: из «+», из календаря (date, time), подзадача плана (parentId),
 * из голоса (s.editorSeed — забираем при открытии). Открытый раз серии (occ) правит всю серию.
 */
import { router } from 'expo-router';
import { useCallback, useEffect, useMemo, useRef, useState } from 'react';
import { StyleSheet, View } from 'react-native';
import { draftFromSeed, draftFromTask, emptyDraft, initialUi, type EditorState } from '@/adapters/editors/draft';
import { endLabel } from '@/adapters/editors/labels';
import { taskEditorProps } from '@/adapters/editors/taskEditor';
import { colorMap, colorOf } from '@/adapters/common/people';
import { kidsOf } from '@/adapters/common/tasks';
import { useStore, type MenuAction } from '@/lib/store';
import type { ID } from '@/lib/types';
import type { CustomReminder } from '@/screens/editors/panels/RemindPanel';
import { TaskEditorScreen, type TaskEditorScreenProps, type TaskField } from '@/screens/editors/TaskEditorScreen';
import { InputSheet } from '@/ui';
import { nav } from '../common/nav';
import { useClock } from '../common/useClock';
import { useInsets } from '../common/useInsets';
import { pickSnapshot, useSnapshot } from '../common/useSnapshot';
import { CustomRemindSheet, EndSheet, UntilSheet } from './EditorSheets';
import { leaveEditor, removeTask, saveDraft, useEditorState, usePanelHandlers, type EditorContext } from './useEditorState';

export type TaskEditorContainerProps = { id: ID | null; occ?: string; date?: string; time?: string; parentId?: ID };

type Sheet = 'title' | 'note' | 'end' | 'until';

const TITLE_MAX = 200;
const NOTE_MAX = 2000;

/** Черновик при открытии: голос (seed) → существующее дело → новое. null — дела уже нет */
function initial(props: TaskEditorContainerProps, today: string): EditorState | null {
  const st = useStore.getState();
  const s = pickSnapshot(st);
  const seed = st.editorSeed;
  const task = props.id ? s.tasks.find((t) => t.id === props.id) : undefined;
  const draft =
    seed && (!props.id || seed.id === props.id)
      ? draftFromSeed(seed, s)
      : task
        ? draftFromTask(task, s, props.occ)
        : props.id
          ? null
          : emptyDraft(s, { date: props.date, time: props.time, parentId: props.parentId });
  return draft ? { draft, ui: initialUi(draft, today) } : null;
}

export function TaskEditorContainer(props: TaskEditorContainerProps) {
  const clock = useClock();
  const [start] = useState(() => initial(props, clock.today));
  // Дело удалили (или его ещё нет на телефоне) — окно сразу закрывается
  useEffect(() => {
    if (!start) leaveEditor();
  }, [start]);
  return start ? <TaskEditor start={start} /> : null;
}

function TaskEditor({ start }: { start: EditorState }) {
  const s = useSnapshot();
  const clock = useClock();
  const insets = useInsets();
  const { state, dispatch, latest } = useEditorState(() => start);
  const { draft } = state;
  const [sheet, setSheet] = useState<Sheet | null>(() => (start.draft.title.trim() ? null : 'title'));
  const [custom, setCustom] = useState<CustomReminder | null>(null);
  const closeSheet = useCallback(() => setSheet(null), []);
  const closeCustom = useCallback(() => setCustom(null), []);

  // Черновик из голоса забран — в хранилище он больше не нужен
  useEffect(() => {
    if (useStore.getState().editorSeed) useStore.getState().setEditorSeed(null);
  }, []);

  const ctx = useRef<EditorContext>({ today: clock.today, snapshot: s });
  ctx.current = { today: clock.today, snapshot: s };

  const handlers = usePanelHandlers({
    dispatch,
    latest,
    ctx,
    onPickUntil: useCallback(() => setSheet('until'), []),
    onCustom: setCustom,
  });

  /** Сохранить и сделать планом: окно плана, поверх — новая подзадача */
  const makePlan = useCallback(() => {
    const d = latest.current.draft;
    if (!d.title.trim()) return setSheet('title');
    const id = saveDraft(d);
    if (!id) return;
    router.replace(nav.planEditor(id));
    router.push(nav.taskEditor({ parentId: id, date: d.date }));
  }, [latest]);

  const onField = useCallback(
    (field: TaskField) => {
      const d = latest.current.draft;
      switch (field) {
        case 'note':
          return setSheet('note');
        case 'end':
          // Без даты конца нет — сначала «КОГДА»
          if (!d.date) return dispatch({ type: 'toggle', field: 'when', today: ctx.current.today });
          dispatch({ type: 'initEnd' });
          dispatch({ type: 'collapse' });
          return setSheet('end');
        case 'subtasks':
          if (d.id && kidsOf(useStore.getState().tasks, d.id).length) return router.push(nav.planEditor(d.id));
          return makePlan();
        default:
          return dispatch({ type: 'toggle', field, today: ctx.current.today });
      }
    },
    [dispatch, latest, makePlan],
  );

  const onSave = useCallback(() => {
    const d = latest.current.draft;
    if (!d.title.trim()) return setSheet('title');
    saveDraft(d);
    leaveEditor();
  }, [latest]);

  const onDelete = useCallback(() => {
    const d = latest.current.draft;
    const st = useStore.getState();
    const task = d.id ? st.tasks.find((t) => t.id === d.id) : undefined;
    if (!task) return leaveEditor();
    if (!task.repeat || !d.occ) return removeTask(task.id);
    const occ = d.occ;
    st.setMenu({
      title: `Удалить «${task.title}»?`,
      actions: [
        { label: 'Только этот раз', danger: true, onPress: () => removeTask(task.id, occ) },
        { label: 'Все повторы', danger: true, onPress: () => removeTask(task.id) },
      ],
    });
  }, [latest]);

  const onMore = useCallback(() => {
    const d = latest.current.draft;
    const st = useStore.getState();
    const task = d.id ? st.tasks.find((t) => t.id === d.id) : undefined;
    const kids = d.id ? kidsOf(st.tasks, d.id).length : 0;
    const actions: MenuAction[] = [];
    const planId = d.parentId ?? (task && kids ? task.id : null);
    if (planId) actions.push({ label: 'Открыть план', onPress: () => router.push(nav.planEditor(planId)) });
    else if (!d.repeat) actions.push({ label: 'Сделать планом', onPress: makePlan });
    if (d.date) actions.push({ label: 'Без даты', onPress: () => dispatch({ type: 'clearDate' }) });
    if (task?.repeat && d.occ) {
      const occ = d.occ;
      actions.push(
        { label: 'Удалить только этот раз', danger: true, onPress: () => removeTask(task.id, occ) },
        { label: 'Удалить все повторы', danger: true, onPress: () => removeTask(task.id) },
      );
    } else if (task) {
      actions.push({ label: 'Удалить', danger: true, onPress: () => removeTask(task.id) });
    }
    if (actions.length) st.setMenu({ title: d.title.trim() || 'Дело', actions });
  }, [dispatch, latest, makePlan]);

  const onEditTitle = useCallback(() => setSheet('title'), []);
  const onClearEnd = useCallback(() => dispatch({ type: 'clearEnd' }), [dispatch]);
  const onTitle = useCallback(
    (title: string) => {
      dispatch({ type: 'title', title });
      setSheet(null);
    },
    [dispatch],
  );
  const onNote = useCallback(
    (note: string) => {
      dispatch({ type: 'note', note });
      setSheet(null);
    },
    [dispatch],
  );
  const onUntil = useCallback((until: string) => dispatch({ type: 'repeatEdit', edit: { kind: 'until', until } }), [dispatch]);

  const data = useMemo(() => taskEditorProps(state.draft, state.ui, s, clock), [state, s, clock]);
  const screen = useMemo<TaskEditorScreenProps>(
    () => ({
      ...data,
      whenPanel: data.whenPanel && { ...data.whenPanel, ...handlers.when },
      repeatPanel: data.repeatPanel && { ...data.repeatPanel, ...handlers.repeat },
      remindPanel: data.remindPanel && { ...data.remindPanel, ...handlers.remind },
      whoPanel: data.whoPanel && { ...data.whoPanel, ...handlers.who },
      insets,
      onBack: leaveEditor,
      onMore,
      onEditTitle,
      onField,
      onClearEnd,
      onDelete,
      onSave,
    }),
    [data, handlers, insets, onMore, onEditTitle, onField, onClearEnd, onDelete, onSave],
  );

  const color = useMemo(() => {
    const colors = colorMap(s);
    return colorOf(colors, draft.people[0] ?? draft.createdBy);
  }, [s, draft.people, draft.createdBy]);

  return (
    <View style={styles.fill}>
      <TaskEditorScreen {...screen} />
      <EndSheet
        visible={sheet === 'end'}
        draft={draft}
        label={endLabel(draft) ?? data.when}
        color={color}
        today={clock.today}
        bottomInset={insets.bottom}
        dispatch={dispatch}
        onClose={closeSheet}
      />
      <UntilSheet
        visible={sheet === 'until'}
        until={draft.repeat?.until ?? null}
        from={draft.date ?? clock.today}
        today={clock.today}
        bottomInset={insets.bottom}
        onPick={onUntil}
        onClose={closeSheet}
      />
      <CustomRemindSheet kind={custom} bottomInset={insets.bottom} onAdd={handlers.addReminder} onClose={closeCustom} />
      <InputSheet
        visible={sheet === 'title'}
        value={draft.title}
        maxLength={TITLE_MAX}
        bottomInset={insets.bottom}
        onSubmit={onTitle}
        onClose={closeSheet}
      />
      <InputSheet
        visible={sheet === 'note'}
        value={draft.note}
        multiline
        maxLength={NOTE_MAX}
        bottomInset={insets.bottom}
        onSubmit={onNote}
        onClose={closeSheet}
      />
    </View>
  );
}

const styles = StyleSheet.create({ fill: { flex: 1 } });
