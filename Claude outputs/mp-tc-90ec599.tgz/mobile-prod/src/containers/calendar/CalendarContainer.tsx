import { useStore } from '@/lib/store';
import { DayContainer } from './DayContainer';
import { MonthContainer } from './MonthContainer';
import { WeekContainer } from './WeekContainer';
import { YearContainer } from './YearContainer';

/** Вкладка «Дела» в виде календаря: вид — s.tasksView (список рисует TasksListContainer) (INTEGRATION.md 1.1, 5.1) */
export const CalendarContainer = () => {
  const view = useStore((s) => s.tasksView);
  switch (view) {
    case 'day':
      return <DayContainer />;
    case 'month':
      return <MonthContainer />;
    case 'year':
      return <YearContainer />;
    default:
      return <WeekContainer />;
  }
};
