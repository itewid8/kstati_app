/**
 * Действия голосовых окон: сохранить, применить правку, открыть редактор или календарь.
 * Окно закрывается до изменения данных — иначе на миг его подхватил бы CardSheet (запись стала дубликатом, дело пропало).
 */
import * as Haptics from 'expo-haptics';
import { router } from 'expo-router';
import { Linking } from 'react-native';
import { deleteChange, editItem, editSeed, occOfChange } from '@/adapters/voice/change';
import type { AgendaSheetData } from '@/adapters/voice/agenda';
import type { Snapshot } from '@/adapters/snapshot';
import type { DeleteScope } from '@/screens/voice';
import { track } from '@/lib/analytics';
import type { PlansAnswer } from '@/lib/plans';
import { useStore } from '@/lib/store';
import { INBOX, type ChangeDraft, type DraftItem } from '@/lib/types';
import { TAB_FOR, beginRecording, cancelVoice, disarmRecording } from '@/lib/voice';
import { nav } from '../common/nav';

const success = () => Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success).catch(() => {});

export const closeCard = () => useStore.getState().setCard(null);

/** Закрыть всё голосовое: запись или разбор — отменить, окно — закрыть */
export function closeVoice() {
  if (useStore.getState().voice !== 'idle') return cancelVoice();
  disarmRecording();
  closeCard();
}

export const retryVoice = () => void beginRecording();

export function openMicSettings() {
  closeCard();
  Linking.openSettings().catch(() => {});
}

/** C-Voice «Сохранить»: запись → вкладка её типа (идея — в тему, подзадача — в план) */
export function saveVoiceItem(item: DraftItem) {
  const s = useStore.getState();
  s.setCard(null);
  const res = s.saveItems([item]);
  track('save', { type: item.type, source: 'voice' });
  success();
  if (item.type === 'idea') router.navigate(nav.topic(res.ideaTopicId ?? INBOX));
  else if (item.type === 'task' && item.data.parentId) router.navigate(nav.planGrid(item.data.parentId));
  else router.navigate(TAB_FOR[item.type]);
}

/** C-Voice «Изменить»: дело — полный редактор с черновиком, остальное — старое окно правки */
export function editVoiceItem(item: DraftItem, transcript: string) {
  const s = useStore.getState();
  if (item.type !== 'task') {
    s.setCard({ source: 'voice', transcript, items: [item], editing: true });
    return;
  }
  s.setCard(null);
  s.setEditorSeed({ ...item.data, ...(item.id ? { id: item.id } : null) });
  router.push(nav.taskEditor({}));
}

/** C-AskDelete «Удалить»: этот раз или вся серия */
export function applyDelete(change: ChangeDraft, scope: DeleteScope, occ: string | null) {
  const s = useStore.getState();
  s.setCard(null);
  s.applyChanges([deleteChange(change, scope, occ)]);
  success();
  router.navigate(TAB_FOR[change.type]);
}

/** C-AskMove: перенести / сохранить / отметить */
export function applyMove(change: ChangeDraft) {
  const s = useStore.getState();
  s.setCard(null);
  s.applyChanges([change]);
  success();
  router.navigate(TAB_FOR[change.type]);
}

/**
 * C-AskMove «Изменить». Дело: правка всей серии или обычного дела — редактор с применённой правкой (назад — ничего не меняет);
 * перенос одного раза серии — раз отделяется (как «Перенести») и открывается уже он. Отметка — редактор этого дела.
 * Хотелка, «Смотреть», идея — старое окно правки
 */
export function editChange(change: ChangeDraft, s: Snapshot) {
  const store = useStore.getState();
  if (change.type !== 'task') {
    const item = editItem(change, s);
    store.setCard(item ? { source: 'edit', items: [item], editing: true } : null);
    return;
  }
  const occ = occOfChange(change, s);
  if (change.action !== 'update') {
    store.setCard(null);
    router.push(nav.taskEditor({ id: change.chosen, ...(occ ? { occ } : null) }));
    return;
  }
  if (occ) {
    const before = new Set(store.tasks.map((t) => t.id));
    store.setCard(null);
    store.applyChanges([change]);
    const moved = useStore.getState().tasks.find((t) => !before.has(t.id));
    router.push(nav.taskEditor({ id: moved?.id ?? change.chosen }));
    return;
  }
  const seed = editSeed(change, s);
  store.setCard(null);
  if (seed) store.setEditorSeed(seed);
  router.push(nav.taskEditor({ id: change.chosen }));
}

/** C-AskWeek / C-AskWeekend «Открыть неделю / день» */
export function openAgenda(answer: PlansAnswer, data: Pick<AgendaSheetData, 'groupId' | 'view'>) {
  const s = useStore.getState();
  s.setCard(null);
  if (data.groupId) s.selectGroup(data.groupId);
  s.setCalendarDate(answer.from);
  s.setTasksView(data.view);
  router.navigate(nav.tab('tasks'));
}
