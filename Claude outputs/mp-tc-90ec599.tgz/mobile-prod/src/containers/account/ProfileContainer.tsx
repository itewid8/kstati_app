import { router } from 'expo-router';
import { useMemo } from 'react';
import { Alert } from 'react-native';
import { profileProps } from '@/adapters/account/profile';
import { colorMap } from '@/adapters/common/people';
import { useStore } from '@/lib/store';
import type { ID, PaletteKey } from '@/lib/types';
import { ProfileScreen } from '@/screens/account/ProfileScreen';
import { nav, useInsets, useSnapshot, type ProfileField } from '../common';

const back = () => (router.canGoBack() ? router.back() : router.navigate(nav.tab('tasks')));
const editAvatar = () => router.push(nav.avatar());
const edit = (field: ProfileField) => () => router.push(nav.profileEdit(field));
const editName = edit('name');
const editNick = edit('nick');
const editGender = edit('gender');
const changePassword = edit('password');
const openGroup = (id: ID) => router.push(nav.group(id));
const createGroup = () => useStore.getState().setGroupSheet(true);
const openAppSettings = () => router.push(nav.appSettings());

const pickColor = (color: PaletteKey) => {
  void useStore
    .getState()
    .setLook({ color })
    .then((err) => {
      if (err) useStore.getState().notice(err);
    });
};

/** Выход стирает данные с телефона (они на сервере и вернутся при входе) */
const logout = () =>
  Alert.alert('Выйти из аккаунта?', undefined, [
    { text: 'Отмена', style: 'cancel' },
    {
      text: 'Выйти',
      style: 'destructive',
      onPress: () => {
        useStore.getState().logout();
        router.replace('/login');
      },
    },
  ]);

const deleteAccount = () =>
  Alert.alert('Удалить аккаунт?', 'Удалятся аккаунт, ваши хотелки и всё, что вы добавили в группы. Это нельзя отменить.', [
    { text: 'Отмена', style: 'cancel' },
    {
      text: 'Удалить',
      style: 'destructive',
      onPress: async () => {
        const err = await useStore.getState().deleteAccount();
        if (err) return Alert.alert('Не удалось удалить', err);
        router.replace('/login');
      },
    },
  ]);

/** C-Profile: имя, ник, пол и пароль — в старой форме settings/edit.tsx, цвет и символ — settings/avatar.tsx */
export function ProfileContainer() {
  const s = useSnapshot();
  const insets = useInsets();
  const colors = useMemo(() => colorMap(s), [s.me, s.users, s.groups]);
  const data = useMemo(() => profileProps(s, colors), [s.me, s.groups, colors]);

  return (
    <ProfileScreen
      {...data}
      insets={insets}
      onBack={back}
      onEditAvatar={editAvatar}
      onEditName={editName}
      onEditNick={editNick}
      onEditGender={editGender}
      onPickColor={pickColor}
      onPickCustomColor={editAvatar}
      onOpenGroup={openGroup}
      onCreateGroup={createGroup}
      onOpenAppSettings={openAppSettings}
      onChangePassword={changePassword}
      onLogout={logout}
      onDeleteAccount={deleteAccount}
    />
  );
}
