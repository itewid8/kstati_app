import React from 'react';
import { CalendarContainer } from '@/containers/calendar/CalendarContainer';
import { TasksListContainer } from '@/containers/lists/TasksListContainer';
import { useStore } from '@/lib/store';

/** «Дела»: список (C-List) или календарь (C-Day / Week / Month / Year) — вид хранится в s.tasksView */
export default function TasksTab() {
  const list = useStore((s) => s.tasksView === 'list');
  return list ? <TasksListContainer /> : <CalendarContainer />;
}
