/** Настройки виджета — без макета, только для просмотра (X-*) */
import { DEFAULT_WIDGET_PREFS, widgetColors } from '@/lib/widgetData';
import { WidgetSettingsScreen } from '@/screens/widget/WidgetSettingsScreen';
import type { Scheme } from '@/ui';

type Props = { theme: Scheme };
const prefs = { ...DEFAULT_WIDGET_PREFS, opacity: 0.7 };
const rows = [
  { key: '1', title: 'Стоматолог', day: null, time: '09:30', strip: [['#2F6BDB', '#5B8DEF']] as const },
  { key: '2', title: 'Йога', day: null, time: '19:00', strip: [['#E2407E', '#F06A9B']] as const },
  { key: '3', title: 'Оплатить коммуналку за октябрь и интернет', day: 'ЗАВТРА', time: '10:00', strip: [['#2F6BDB', '#5B8DEF']] as const },
];

export const screens = {
  'X-WidgetSettings': ({ theme }: Props) => (
    <WidgetSettingsScreen
      prefs={prefs}
      preview={{ colors: widgetColors(prefs, theme), header: { label: 'МЫ С КАРИНОЙ', weekday: 'ПН', day: '05' }, rows, dark: theme === 'dark' }}
      groups={[{ id: 'g1', name: 'Мы с Кариной' }, { id: 'g2', name: 'Семья' }]}
      canSave
      insets={{ top: 0, bottom: 0 }}
    />
  ),
};
