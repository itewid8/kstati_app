/**
 * Настройки виджета. Без widgetId — общие для всех виджетов (из настроек приложения): сохраняются в «default»,
 * свои настройки виджетов сбрасываются. С widgetId — окно «Настроить» одного виджета на Android.
 */
import { router } from 'expo-router';
import { useCallback, useMemo, useState } from 'react';
import { useStore } from '@/lib/store';
import {
  myGroups,
  prefsFor,
  todayOf,
  visibleAt,
  whenParts,
  widgetColors,
  widgetFile,
  widgetHeader,
  withSharedPrefs,
  withWidgetPrefs,
  type WidgetPrefs,
} from '@/lib/widgetData';
import { useTheme } from '@/ui';
import { WidgetSettingsScreen } from '@/screens/widget/WidgetSettingsScreen';
import { finishWidgetConfig, reloadWidget, reloadWidgets } from '../../../modules/kstati-widget';
import { readPrefsFile, writePrefsFile } from '../../widget/files';
import { updateWidget } from '../../widget/sync';
import { useInsets } from '../common';

type Props = { widgetId?: number };

const samePrefs = (a: WidgetPrefs, b: WidgetPrefs) => (Object.keys(a) as (keyof WidgetPrefs)[]).every((k) => a[k] === b[k]);

export function WidgetSettingsContainer({ widgetId }: Props) {
  const insets = useInsets();
  const me = useStore((s) => s.me);
  const allGroups = useStore((s) => s.groups);
  const groups = useMemo(() => (me ? myGroups({ me, groups: allGroups }) : []), [me, allGroups]);
  const initial = useMemo(() => prefsFor(readPrefsFile(), widgetId ?? null), [widgetId]);
  const [prefs, setPrefs] = useState(initial);
  const { scheme } = useTheme();
  const users = useStore((s) => s.users);
  const tasks = useStore((s) => s.tasks);
  const theme = useStore((s) => s.theme);
  const file = useMemo(() => (me ? widgetFile({ me, users, groups: allGroups, tasks }, theme, new Date()) : null), [me, users, allGroups, tasks, theme]);
  const preview = useMemo(() => {
    const now = Date.now();
    const today = todayOf(now);
    const items = file ? visibleAt(file.items, now, 4, prefs.group) : [];
    return {
      colors: widgetColors(prefs, scheme),
      header: widgetHeader(file?.groups ?? [], prefs.group, today),
      rows: items.map((x) => ({ key: `${x.id}@${x.occ ?? ''}`, title: x.title, strip: x.c, ...whenParts(x.date, x.time, today) })),
      dark: scheme === 'dark',
    };
  }, [file, prefs, scheme]);

  const close = useCallback(
    (saved: boolean) => {
      if (widgetId !== undefined) finishWidgetConfig(saved);
      else if (router.canGoBack()) router.back();
    },
    [widgetId],
  );

  const onSave = useCallback(() => {
    try {
      writePrefsFile(widgetId !== undefined ? withWidgetPrefs(readPrefsFile(), widgetId, prefs) : withSharedPrefs(prefs));
      updateWidget();
      if (widgetId !== undefined) reloadWidget(widgetId);
      else reloadWidgets();
    } catch (e) {
      console.warn('Настройки виджета не сохранены', e);
    }
    close(true);
  }, [prefs, widgetId, close]);

  return (
    <WidgetSettingsScreen
      prefs={prefs}
      preview={preview}
      groups={groups}
      canSave={!samePrefs(prefs, initial)}
      insets={insets}
      onChange={setPrefs}
      onCancel={() => close(false)}
      onSave={onSave}
    />
  );
}
