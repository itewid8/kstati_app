/**
 * Живое превью виджета в настройках: та же раскладка, что у Android-виджета (KstatiWidget.kt, «высокий» вид) —
 * шапка (группа и сегодня), строки дел с полосой людей, время справа, квадратная кнопка REC.
 * Под виджетом — клетчатая «обоина», чтобы была видна прозрачность фона.
 */
import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { StripColor, WidgetColors } from '@/lib/widgetData';
import { Marquee, fonts, size as S } from '@/ui';

export type PreviewRow = { key: string; title: string; day: string | null; time: string; strip: readonly StripColor[] };
export type PreviewHeader = { label: string; weekday: string; day: string };

type Props = { colors: WidgetColors; header: PreviewHeader; rows: readonly PreviewRow[]; dark: boolean };

const CHECK = 14;
const COLS = 26;
const ROWS = 16;

const Wallpaper = memo(function Wallpaper({ dark }: { dark: boolean }) {
  const a = dark ? '#2A2A28' : '#BDBCB6';
  const b = dark ? '#1A1A19' : '#D9D8D2';
  return (
    <View style={StyleSheet.absoluteFill} pointerEvents="none">
      {Array.from({ length: ROWS }, (_, r) => (
        <View key={r} style={styles.checkRow}>
          {Array.from({ length: COLS }, (_, col) => (
            <View key={col} style={[styles.check, { backgroundColor: (r + col) % 2 ? a : b }]} />
          ))}
        </View>
      ))}
    </View>
  );
});

export const WidgetPreview = memo(function WidgetPreview({ colors: c, header, rows, dark }: Props) {
  return (
    <View style={styles.stage}>
      <Wallpaper dark={dark} />
      <View style={styles.widget}>
        <View style={[StyleSheet.absoluteFill, { backgroundColor: c.card, opacity: c.alpha }]} />
        <View style={[styles.box, { borderColor: c.border }]}>
          <View style={[StyleSheet.absoluteFill, { backgroundColor: c.panel, opacity: c.alpha }]} />
          <View style={[styles.head, { backgroundColor: c.headBg }]}>
            <Marquee style={[styles.headText, styles.headLabel, { color: c.headInk }]}>{header.label}</Marquee>
            <Text style={[styles.headText, { color: c.headInk }]}>{header.weekday}</Text>
            <View style={[styles.today, { backgroundColor: c.today }]}>
              <Text style={[styles.headText, { color: c.todayInk }]}>{header.day}</Text>
            </View>
          </View>
          {rows.length === 0 ? (
            <View style={[styles.row, { borderTopColor: c.hair }]}>
              <Text style={[styles.title, { color: c.empty }]}>—</Text>
            </View>
          ) : (
            rows.map((r) => (
              <View key={r.key} style={[styles.row, { borderTopColor: c.hair }]}>
                <View style={styles.strip}>
                  {r.strip.map((s, i) => (
                    <View key={i} style={[styles.stripPart, { backgroundColor: dark ? s[1] : s[0] }]} />
                  ))}
                </View>
                <Marquee style={[styles.title, { color: c.title }]}>{r.title}</Marquee>
                {r.day ? <Text style={[styles.day, { color: c.day }]}>{r.day}</Text> : null}
                <Text style={[styles.time, { color: c.time }]}>{r.time}</Text>
              </View>
            ))
          )}
        </View>
        {c.showMic ? (
          <View style={[styles.rec, { backgroundColor: c.recFill, borderColor: c.recBorder }]}>
            <View style={[styles.recDot, { backgroundColor: c.recDot }]} />
            <Text style={[styles.recText, { color: c.recInk }]}>REC</Text>
          </View>
        ) : null}
      </View>
    </View>
  );
});

const styles = StyleSheet.create({
  stage: { height: 220, overflow: 'hidden', padding: 18, justifyContent: 'center' },
  checkRow: { flexDirection: 'row' },
  check: { width: CHECK, height: CHECK },
  widget: { padding: 10, gap: 8, overflow: 'hidden' },
  box: { borderWidth: S.border, overflow: 'hidden' },
  head: { height: 22, paddingHorizontal: 8, flexDirection: 'row', alignItems: 'center', gap: 6 },
  headText: { fontFamily: fonts.mono600, fontSize: 9, letterSpacing: 0.72 },
  headLabel: { flex: 1 },
  today: { paddingHorizontal: 4, height: 16, justifyContent: 'center' },
  row: { height: 30, flexDirection: 'row', alignItems: 'center', gap: 8, paddingRight: 8, borderTopWidth: 1 },
  strip: { width: 1.5, alignSelf: 'stretch' },
  stripPart: { flex: 1 },
  title: { flex: 1, fontFamily: fonts.sans500, fontSize: 12 },
  day: { fontFamily: fonts.mono400, fontSize: 8.5, letterSpacing: 0.4 },
  time: { fontFamily: fonts.mono600, fontSize: 11 },
  rec: { alignSelf: 'flex-end', width: 44, height: 44, borderWidth: S.border, alignItems: 'center', justifyContent: 'center', gap: 3 },
  recDot: { width: 9, height: 9, borderRadius: 5 },
  recText: { fontFamily: fonts.mono600, fontSize: 8, letterSpacing: 0.8 },
});
