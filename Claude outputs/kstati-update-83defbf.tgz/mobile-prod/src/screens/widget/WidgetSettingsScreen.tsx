/**
 * Настройки виджета на рабочем столе: кнопка REC и её цвет, фон и прозрачность, цвет названий и времени, группа.
 * Открывается из настроек приложения (общие для всех виджетов) и из «Настроить» на самом виджете (Android, свои у виджета).
 * Презентационный экран: данные — пропсами, действия — колбэками. Снизу ОТМЕНА / СОХРАНИТЬ.
 */
import { memo } from 'react';
import { StyleSheet, Text, View } from 'react-native';
import type { WidgetColors, WidgetPrefs, WidgetTone } from '@/lib/widgetData';
import { SectionBox, size as S, useTheme } from '@/ui';
import { AccountPage, type PageInsets } from '../account/components/AccountPage';
import { OptionGrid, type Option } from '../account/components/OptionGrid';
import { Toggle } from '../account/components/Toggle';
import { accountText } from '../account/components/accountTheme';
import { Slider } from './components/Slider';
import { WidgetPreview, type PreviewHeader, type PreviewRow } from './components/WidgetPreview';

export type WidgetGroupOption = { id: string; name: string };

export type WidgetSettingsScreenProps = {
  prefs: WidgetPrefs;
  preview: { colors: WidgetColors; header: PreviewHeader; rows: readonly PreviewRow[]; dark: boolean };
  groups: readonly WidgetGroupOption[];
  canSave: boolean;
  insets: PageInsets;
  onChange?: (prefs: WidgetPrefs) => void;
  onCancel?: () => void;
  onSave?: () => void;
};

const TONES: ReadonlyArray<Option<WidgetTone>> = [
  { key: 'auto', label: 'КАК В ТЕМЕ' },
  { key: 'light', label: 'СВЕТЛЫЙ' },
  { key: 'dark', label: 'ТЁМНЫЙ' },
];

const ALL = 'all';

export const WidgetSettingsScreen = memo(function WidgetSettingsScreen(props: WidgetSettingsScreenProps) {
  const { prefs, preview, groups, canSave, insets, onChange, onCancel, onSave } = props;
  const { c } = useTheme();
  const set = (patch: Partial<WidgetPrefs>) => onChange?.({ ...prefs, ...patch });
  const groupOptions: ReadonlyArray<Option<string>> = [{ key: ALL, label: 'ВСЕ' }, ...groups.map((g) => ({ key: g.id, label: g.name.toUpperCase() }))];

  return (
    <AccountPage caption="НАСТРОЙКИ" title="Виджет" insets={insets} onBack={onCancel} save={{ canSave, onCancel, onSave }}>
      <SectionBox title="ПРЕВЬЮ">
        <WidgetPreview colors={preview.colors} header={preview.header} rows={preview.rows} dark={preview.dark} />
      </SectionBox>
      <SectionBox title="КНОПКА REC">
        <View style={[styles.switchRow, { backgroundColor: c.panel }]}>
          <Text style={[accountText.rowLabel, { color: c.text }]}>Показывать</Text>
          <Toggle value={prefs.mic} onChange={(mic) => set({ mic })} accessibilityLabel="Кнопка REC" />
        </View>
        {prefs.mic ? <OptionGrid options={TONES} value={prefs.micTone} onChange={(micTone) => set({ micTone })} /> : null}
      </SectionBox>
      <SectionBox title="ФОН">
        <OptionGrid options={TONES} value={prefs.bg} onChange={(bg) => set({ bg })} />
      </SectionBox>
      <SectionBox title="ПРОЗРАЧНОСТЬ ФОНА" count={`${Math.round((1 - prefs.opacity) * 100)}%`}>
        <Slider value={1 - prefs.opacity} onChange={(t) => set({ opacity: Math.round((1 - t) * 100) / 100 })} accessibilityLabel="Прозрачность фона" />
      </SectionBox>
      <SectionBox title="НАЗВАНИЯ">
        <OptionGrid options={TONES} value={prefs.text} onChange={(text) => set({ text })} />
      </SectionBox>
      <SectionBox title="ВРЕМЯ">
        <OptionGrid options={TONES} value={prefs.time} onChange={(time) => set({ time })} />
      </SectionBox>
      {groups.length > 1 ? (
        <SectionBox title="ГРУППА">
          <OptionGrid options={groupOptions} value={prefs.group ?? ALL} onChange={(g) => set({ group: g === ALL ? null : g })} />
        </SectionBox>
      ) : null}
    </AccountPage>
  );
});

const styles = StyleSheet.create({
  switchRow: {
    height: S.row,
    paddingHorizontal: 8,
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
  },
});
